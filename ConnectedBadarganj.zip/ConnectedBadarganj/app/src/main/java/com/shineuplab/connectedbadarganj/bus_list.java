package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class bus_list extends AppCompatActivity implements View.OnClickListener {

    CardView haque, nabil, arafat, imran;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_list);

        haque = findViewById(R.id.haque);
        nabil = findViewById(R.id.nabil);
        arafat = findViewById(R.id.arafat);
        imran = findViewById(R.id.imran);

        haque.setOnClickListener(this);
        nabil.setOnClickListener(this);
        arafat.setOnClickListener(this);
        imran.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId()==R.id.haque){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.hauqe));
            intent.putExtra("phone", getResources().getString(R.string.haque_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.haque_counter));
            startActivity(intent);
        }
        if (v.getId()==R.id.nabil){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.nabil));
            intent.putExtra("phone", getResources().getString(R.string.nabil_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.nabil_counter));
            startActivity(intent);

        }
        if (v.getId()==R.id.arafat){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.arafat));
            intent.putExtra("phone", getResources().getString(R.string.arafat_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.arafat_counter));
            startActivity(intent);

        }
        if (v.getId()==R.id.imran){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.imran));
            intent.putExtra("phone", getResources().getString(R.string.imran_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.imran_counter));
            startActivity(intent);

        }
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
