package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class healthCare extends AppCompatActivity implements View.OnClickListener {

    CardView dcHealthCareCv_1, dcHealthCareCv_2, dcHealthCareCv_3, dcHealthCareCv_4, dcHealthCareCv_5, dcHealthCareCv_6, dcHealthCareCv_7, dcHealthCareCv_8, dcHealthCareCv_9, dcHealthCareCv_10, dcHealthCareCv_11, dcHealthCareCv_12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_care);

        dcHealthCareCv_1 = findViewById(R.id.dcHealthCareCv_1);
        dcHealthCareCv_2 = findViewById(R.id.dcHealthCareCv_2);
        dcHealthCareCv_3 = findViewById(R.id.dcHealthCareCv_3);
        dcHealthCareCv_4 = findViewById(R.id.dcHealthCareCv_4);
        dcHealthCareCv_5 = findViewById(R.id.dcHealthCareCv_5);
        dcHealthCareCv_6 = findViewById(R.id.dcHealthCareCv_6);
        dcHealthCareCv_7 = findViewById(R.id.dcHealthCareCv_7);
        dcHealthCareCv_8 = findViewById(R.id.dcHealthCareCv_8);
        dcHealthCareCv_9  = findViewById(R.id.dcHealthCareCv_9);
        dcHealthCareCv_10 = findViewById(R.id.dcHealthCareCv_10);
        dcHealthCareCv_11 = findViewById(R.id.dcHealthCareCv_11);
        dcHealthCareCv_12 = findViewById(R.id.dcHealthCareCv_12);

        dcHealthCareCv_1.setOnClickListener(this);
        dcHealthCareCv_2.setOnClickListener(this);
        dcHealthCareCv_3.setOnClickListener(this);
        dcHealthCareCv_4.setOnClickListener(this);
        dcHealthCareCv_5.setOnClickListener(this);
        dcHealthCareCv_6.setOnClickListener(this);
        dcHealthCareCv_7.setOnClickListener(this);
        dcHealthCareCv_8.setOnClickListener(this);
        dcHealthCareCv_9.setOnClickListener(this);
        dcHealthCareCv_10.setOnClickListener(this);
        dcHealthCareCv_11.setOnClickListener(this);
        dcHealthCareCv_12.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()== R.id.dcHealthCareCv_1){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_medicine_name_1));
            intent.putExtra("details", getString(R.string.hc_medicine_details_1));
            intent.putExtra("time", getString(R.string.hc_medicine_time_1));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_2){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_medicine_name_2));
            intent.putExtra("details", getString(R.string.hc_medicine_details_2));
            intent.putExtra("time", getString(R.string.hc_medicine_time_2));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_3){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_medicine_name_3));
            intent.putExtra("details", getString(R.string.hc_medicine_details_3));
            intent.putExtra("time", getString(R.string.hc_medicine_time_3));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_4){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_medicine_name_4));
            intent.putExtra("details", getString(R.string.hc_medicine_details_4));
            intent.putExtra("time", getString(R.string.hc_medicine_time_4));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_5){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_gynecologist_name_1));
            intent.putExtra("details", getString(R.string.hc_gynecologist_details_1));
            intent.putExtra("time", getString(R.string.hc_gynecologist_time_1));
            intent.putExtra("speciality", getString(R.string.Gynecologists_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_6){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_gynecologist_name_2));
            intent.putExtra("details", getString(R.string.hc_gynecologist_details_2));
            intent.putExtra("time", getString(R.string.hc_gynecologist_time_2));
            intent.putExtra("speciality", getString(R.string.Gynecologists_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_7){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_gynecologist_name_3));
            intent.putExtra("details", getString(R.string.hc_gynecologist_details_3));
            intent.putExtra("time", getString(R.string.hc_gynecologist_time_3));
            intent.putExtra("speciality", getString(R.string.Gynecologists_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_8){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_Pediatricians_name_1));
            intent.putExtra("details", getString(R.string.hc_Pediatricians_details_1));
            intent.putExtra("time", getString(R.string.hc_Pediatricians_time_1));
            intent.putExtra("speciality", getString(R.string.Pediatricians_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_9){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_ent_name_1));
            intent.putExtra("details", getString(R.string.hc_ent_details_1));
            intent.putExtra("time", getString(R.string.hc_ent_time_1));
            intent.putExtra("speciality", getString(R.string.ent_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_10){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_Paralysis_name_1));
            intent.putExtra("details", getString(R.string.hc_Paralysis_details_1));
            intent.putExtra("time", getString(R.string.hc_Paralysis_time_1));
            intent.putExtra("speciality", getString(R.string.Paralysis_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_11){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_Paralysis_name_2));
            intent.putExtra("details", getString(R.string.hc_Paralysis_details_2));
            intent.putExtra("time", getString(R.string.hc_Paralysis_time_2));
            intent.putExtra("speciality", getString(R.string.Paralysis_sp));
            intent.putExtra("serial", getString(R.string.hc_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcHealthCareCv_12){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.hc_Paralysis_name_3));
            intent.putExtra("details", getString(R.string.hc_Paralysis_details_3));
            intent.putExtra("time", getString(R.string.hc_Paralysis_time_3));
            intent.putExtra("speciality", getString(R.string.Paralysis_sp));
            intent.putExtra("serial",getString(R.string.hc_serial));
            startActivity(intent);
        }
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
