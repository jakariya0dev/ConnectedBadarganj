package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class EducationalOrganization extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educational_organization);


    }

    public void college(View view) {
        Intent intent = new Intent(getApplicationContext(),college.class);
        startActivity(intent);
    }

    public void school_and_college(View view) {
        Intent intent = new Intent(getApplicationContext(),school_and_college.class);
        startActivity(intent);
    }

    public void high_school(View view) {
        Intent intent = new Intent(getApplicationContext(),high_school.class);
        startActivity(intent);
    }

    public void school(View view) {
        Intent intent = new Intent(getApplicationContext(),school.class);
        startActivity(intent);
    }

    public void kinder_garden(View view) {
        Intent intent = new Intent(getApplicationContext(),kinder_garden.class);
        startActivity(intent);
    }

    public void fazil_madrasah(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.fazil_madrasah_name_1));
        intent.putExtra("description",getString(R.string.fazil_madrasah_description_1));
        startActivity(intent);
    }

    public void alim_madrasah(View view) {
        Intent intent = new Intent(getApplicationContext(),alim_madrasah.class);
        startActivity(intent);
    }

    public void dakhil_madrasah(View view) {
        Intent intent = new Intent(getApplicationContext(),dakhil_madrasah.class);
        startActivity(intent);
    }

    public void ebtedayee_madrasah(View view) {
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
