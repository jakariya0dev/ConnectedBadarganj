package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class diagnostic_center extends AppCompatActivity implements View.OnClickListener {

    CardView MhCv, HealthCareCv, DrMokhlecherCv, BadarganjCv, ApolloCv, SinhaCv, OishiCv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnostic_center);

        MhCv = findViewById(R.id.MhCv);
        HealthCareCv = findViewById(R.id.HealthCareCv);
        DrMokhlecherCv  = findViewById(R.id.DrMokhlecherCv);
        BadarganjCv  = findViewById(R.id.BadarganjCv);
        ApolloCv = findViewById(R.id.ApolloCv);
        SinhaCv  = findViewById(R.id.SinhaCv);
        OishiCv  = findViewById(R.id.OishiCv);

        MhCv.setOnClickListener(this);
        HealthCareCv.setOnClickListener(this);
        DrMokhlecherCv.setOnClickListener(this);
        BadarganjCv.setOnClickListener(this);
        ApolloCv.setOnClickListener(this);
        SinhaCv.setOnClickListener(this);
        OishiCv.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.MhCv){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.HealthCareCv){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.DrMokhlecherCv){
            Intent intent = new Intent(getApplicationContext(),dc_mokhlechar.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.ApolloCv){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.SinhaCv){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.OishiCv){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        } 
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
