package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class up_entraprenour extends AppCompatActivity {

    TextView headingOneTv, headingTwoTv, PhoneOneTv, PhoneTwoTv, EmailOneTv, EmailTwoTv, UpNameHeadingTv;
    Button callButtonOne, callButtonTwo, smsButtonOne, smsButtonTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_entraprenour);

        headingOneTv = findViewById(R.id.headingOneTv);
        headingTwoTv = findViewById(R.id.headingTwoTv);
        PhoneOneTv = findViewById(R.id.PhoneOneTv);
        PhoneTwoTv  = findViewById(R.id.PhoneTwoTv);
        EmailOneTv  = findViewById(R.id.EmailOneTv);
        EmailTwoTv  = findViewById(R.id.EmailTwoTv);
        UpNameHeadingTv  = findViewById(R.id.UpNameHeadingTv);
        callButtonOne  = findViewById(R.id.callButtonOne);
        callButtonTwo  = findViewById(R.id.callButtonTwo);
        smsButtonOne  = findViewById(R.id.smsButtonOne);
        smsButtonTwo  = findViewById(R.id.smsButtonTwo);

        Bundle bundle = getIntent().getExtras();

        if (bundle!=null){

            String UpNameHeading = bundle.getString("UpNameHeading");
            String NameOne = bundle.getString("nameOne");
            String NameTwo = bundle.getString("nameTwo");
            String PhoneOne = bundle.getString("phoneOne");
            String PhoneTwo = bundle.getString("phoneTwo");
            String EmailOne = bundle.getString("emailOne");
            String EmailTwo = bundle.getString("emailTwo");

            UpNameHeadingTv.setText(UpNameHeading);
            headingOneTv.setText(NameOne);
            headingTwoTv.setText(NameTwo);
            PhoneOneTv.setText(PhoneOne);
            PhoneTwoTv.setText(PhoneTwo);
            EmailOneTv.setText(EmailOne);
            EmailTwoTv.setText(EmailTwo);
        }

        callButtonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = PhoneOneTv.getText().toString();
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+phoneNumber));
                startActivity(intent);
            }
        });

        callButtonTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = PhoneTwoTv.getText().toString();
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+phoneNumber));
                startActivity(intent);
            }
        });
        smsButtonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = PhoneOneTv.getText().toString();
                Intent smsIntent = new Intent(Intent.ACTION_VIEW);
                smsIntent.setType("vnd.android-dir/mms-sms");
                smsIntent.putExtra("address", phoneNumber);
                smsIntent.putExtra("sms_body","");
                startActivity(smsIntent);
            }
        });

        smsButtonTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = PhoneTwoTv.getText().toString();
                Intent smsIntent = new Intent(Intent.ACTION_VIEW);
                smsIntent.setType("vnd.android-dir/mms-sms");
                smsIntent.putExtra("address", phoneNumber);
                smsIntent.putExtra("sms_body","");
                startActivity(smsIntent);
            }
        });

    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(), Adv_private.class);
        startActivity(intent);
    }
}
