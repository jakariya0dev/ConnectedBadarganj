package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;



public class train extends AppCompatActivity {

    TextView TrainNoTv, NameTv, timeTv, StartingPointTv, EndPointTv, StopsTv;
    //LinearLayout OfflineAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_train);

        TrainNoTv = findViewById(R.id.TrainNoTv);
        NameTv = findViewById(R.id.FirstNameTv);
        timeTv = findViewById(R.id.timeTv);
        StartingPointTv = findViewById(R.id.StartingPointTv);
        EndPointTv = findViewById(R.id.EndPointTv);
        StopsTv = findViewById(R.id.StopsTv);

        //OfflineAdd = findViewById(R.id.OfflineAdd);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            String trainNo = bundle.getString("trainNo");
            String trainName = bundle.getString("trainName");
            String arrived = bundle.getString("arrived");
            String stops = bundle.getString("stops");
            String startingPoint = bundle.getString("StartingPoint");
            String endPoint = bundle.getString("EndPoint");

            TrainNoTv.setText(trainNo);
            NameTv.setText(trainName);
            timeTv.setText(arrived);
            StopsTv.setText(stops);
            StartingPointTv.setText(startingPoint);
            EndPointTv.setText(endPoint);

        }

    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}

