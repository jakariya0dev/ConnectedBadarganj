package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class administration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administration);

        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.uno_pro);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.uno_name));
        intent.putExtra("position",getString(R.string.uno));
        intent.putExtra("description",getString(R.string.bdg_up));
        intent.putExtra("phone",getString(R.string.uno_phone));
        intent.putExtra("email",getString(R.string.uno_email));
        startActivity(intent);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
