package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void introduction(View view) {
        Intent i = new Intent(getApplicationContext(),Introduction.class);
        startActivity(i);
    }

    public void emergency_service(View view) {
        Intent i = new Intent(getApplicationContext(),emergency_service.class);
        startActivity(i);
    }

    public void doctor_chamber(View view) {
        Intent i = new Intent(getApplicationContext(),doctor_chamber.class);
        startActivity(i);
    }

    public void train_time_table(View view) {
        Intent i = new Intent(getApplicationContext(),train_time_table.class);
        startActivity(i);
    }

    public void busList(View view) {
        Intent i = new Intent(getApplicationContext(),bus_list.class);
        startActivity(i);
    }

    public void up(View view) {
        Intent i = new Intent(getApplicationContext(),common_union.class);
        startActivity(i);
    }

    public void bdg_pourosova(View view) {
        Intent i = new Intent(getApplicationContext(),bdg_pourosova.class);
        startActivity(i);
    }

    public void spectacular_place(View view) {
        Intent i = new Intent(getApplicationContext(),Spectacular_place.class);
        startActivity(i);
    }

    public void journalist(View view) {
        Intent i = new Intent(getApplicationContext(),journalist.class);
        startActivity(i);

    }

    public void personality(View view) {
        Intent i = new Intent(getApplicationContext(),personality.class);
        startActivity(i);
    }

    public void leader(View view) {
        Intent i = new Intent(getApplicationContext(),leader.class);
        startActivity(i);
    }

    public void EducationalOrganization(View view) {
        Intent i = new Intent(getApplicationContext(),EducationalOrganization.class);
        startActivity(i);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    public void Uno(View view) {

        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.uno_pro);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.uno_name));
        intent.putExtra("position",getString(R.string.uno));
        intent.putExtra("description",getString(R.string.bdg_up));
        intent.putExtra("phone",getString(R.string.uno_phone));
        intent.putExtra("email",getString(R.string.uno_email));
        startActivity(intent);
    }

    public void govt_office(View view) {
        Intent i = new Intent(getApplicationContext(),govt_office.class);
        startActivity(i);
    }

    public void bloodDonor(View view) {
        Intent i = new Intent(getApplicationContext(),BloodDonor.class);
        startActivity(i);
    }
}
