package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class emergency_service extends AppCompatActivity implements View.OnClickListener {

    CardView policeCv, fireServiceCv, hospitalCv, ambulanceCv, electricityCv, tripleNineCv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_service);

        policeCv = findViewById(R.id.policeCv);
        fireServiceCv = findViewById(R.id.fireServiceCv);
        hospitalCv = findViewById(R.id.hospitalCv);
        ambulanceCv = findViewById(R.id.ambulanceCv);
        electricityCv = findViewById(R.id.electricityCv);
        tripleNineCv = findViewById(R.id.tripleNineCv);

        policeCv.setOnClickListener(this);
        fireServiceCv.setOnClickListener(this);
        hospitalCv.setOnClickListener(this);
        ambulanceCv.setOnClickListener(this);
        electricityCv.setOnClickListener(this);
        tripleNineCv.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId()==R.id.policeCv){
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+getString(R.string.officerInChargePhone)));
            startActivity(intent);
        }if (v.getId()==R.id.fireServiceCv){
            Intent intent = new Intent(getApplicationContext(), emergency_service2.class);
            intent.putExtra("headingOne",getString(R.string.MobileNumber));
            intent.putExtra("headingTwo",getString(R.string.PhoneNumber));
            intent.putExtra("PhoneOne",getString(R.string.fireMobileNumber));
            intent.putExtra("PhoneTwo",getString(R.string.firePhoneNumber));
            intent.putExtra("title",getString(R.string.fscd));
            startActivity(intent);
        }if (v.getId()==R.id.ambulanceCv){
            Intent intent = new Intent(getApplicationContext(), emergency_service2.class);
            intent.putExtra("headingOne",getString(R.string.ambulanceOne));
            intent.putExtra("headingTwo",getString(R.string.ambulanceTwo));
            intent.putExtra("PhoneOne",getString(R.string.ambulanceOnePhone));
            intent.putExtra("PhoneTwo",getString(R.string.ambulanceTwoPhone));
            intent.putExtra("title",getString(R.string.ambulance_service));
            startActivity(intent);
        }if (v.getId()==R.id.hospitalCv){
            Intent intent = new Intent(getApplicationContext(), emergency_service2.class);
            intent.putExtra("headingOne",getString(R.string.MobileNumber));
            intent.putExtra("headingTwo",getString(R.string.PhoneNumber));
            intent.putExtra("PhoneOne",getString(R.string.hospitalMobileNumber));
            intent.putExtra("PhoneTwo",getString(R.string.hospitalPhoneNumber));
            intent.putExtra("title",getString(R.string.uhc));
            startActivity(intent);
        }if (v.getId()==R.id.electricityCv){
            Intent intent = new Intent(getApplicationContext(), emergency_service2.class);
            intent.putExtra("headingOne",getString(R.string.electricityOne));
            intent.putExtra("headingTwo",getString(R.string.electricityTwo));
            intent.putExtra("PhoneOne",getString(R.string.electricityOnePhone));
            intent.putExtra("PhoneTwo",getString(R.string.electricityTwoPhone));
            intent.putExtra("title",getString(R.string.rpbs2));
            startActivity(intent);
        }if (v.getId()==R.id.tripleNineCv){
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+getString(R.string.nineNineNine)));
            startActivity(intent);
        }
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
