package com.shineuplab.connectedbadarganj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class BloodDonorRegForm extends AppCompatActivity {

    EditText signUpNameEditText, signUpBloodGroupEditText, signUpAgeEditText;
    EditText signPhoneEditText, signUpEmailEditText, signUpPasswordEditText;
    Button SignUpButton;
    ProgressBar progressBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_donor_reg_form);

        signUpNameEditText = findViewById(R.id.signUpNameEditText);
        signUpBloodGroupEditText = findViewById(R.id.signUpBloodGroupEditText);
        signUpAgeEditText = findViewById(R.id.signUpAgeEditText);
        signPhoneEditText = findViewById(R.id.signUpPhoneEditText);
        signUpEmailEditText = findViewById(R.id.signUpEmailEditText);
        signUpPasswordEditText = findViewById(R.id.signUpPasswordEditText);

        SignUpButton = findViewById(R.id.SignUpButton);
        progressBar = findViewById(R.id.signUpProgressBarId);

        mAuth = FirebaseAuth.getInstance();

        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String name = signUpNameEditText.getText().toString().trim();
                final String blood_group =  signUpBloodGroupEditText.getText().toString().trim();
                final String age = signUpAgeEditText.getText().toString().trim();
                final String phone = signPhoneEditText.getText().toString().trim();
                final String email = signUpEmailEditText.getText().toString().trim();
                final String password = signUpPasswordEditText.getText().toString().trim();

                if (name.isEmpty()) {
                    signUpNameEditText.setError("Enter an User Name");
                    signUpNameEditText.requestFocus();
                    return;
                }
                if (blood_group.isEmpty()) {
                    signUpBloodGroupEditText.setError("Enter a Blood Group");
                    signUpBloodGroupEditText.requestFocus();
                    return;
                }
                if (age.isEmpty()) {
                    signUpAgeEditText.setError("Enter Your Age");
                    signUpAgeEditText.requestFocus();
                    return;
                }
                if (phone.isEmpty()) {
                    signPhoneEditText.setError("Enter a Phone Number");
                    signPhoneEditText.requestFocus();
                    return;
                }
                if (phone.length() < 11){
                    signPhoneEditText.setError("Phone Number Must Be 11 Digit");
                    signPhoneEditText.requestFocus();
                    return;
                }
                if (email.isEmpty()) {
                    signUpEmailEditText.setError("Enter Your Email Address");
                    signUpEmailEditText.requestFocus();
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    signUpEmailEditText.setError("Enter Your Email Address");
                    signUpEmailEditText.requestFocus();
                    return;
                }
                if (password.isEmpty()) {
                    signUpPasswordEditText.setError("Enter a Password");
                    signUpPasswordEditText.requestFocus();
                    return;
                }
                if (password.length() < 6) {
                    signUpPasswordEditText.setError("Password must be 6 Charectar or more");
                    signUpPasswordEditText.requestFocus();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);

                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Authentication Success.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), BloodDonorDashboard.class);
                            startActivity(intent);

                        } else {
                            Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                        }

                    }
                });




            }
        });
    }
}