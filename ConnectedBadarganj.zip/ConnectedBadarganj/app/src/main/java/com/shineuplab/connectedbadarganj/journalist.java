package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;

public class journalist extends AppCompatActivity implements View.OnClickListener {

    CardView prothom_alo, kaler_kantho, somokal, noyadigonto, manobjomin, vorerkagoj, dinkal,
            zayzaydin, manobkantho, inkilab, zugantor, ittefak, zuger_alo, jonokantho, songram;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journalist);


        prothom_alo = findViewById(R.id.prothom_alo_cv);
        kaler_kantho = findViewById(R.id.kaler_kantho_cv);
        somokal = findViewById(R.id.somokal_cv);
        noyadigonto = findViewById(R.id.noyadigonto_cv);
        manobjomin = findViewById(R.id.manobjomin_cv);
        vorerkagoj = findViewById(R.id.vorerkagoj_cv);
        dinkal = findViewById(R.id.dinkal_cv);
        zayzaydin = findViewById(R.id.zayzaydin_cv);
        manobkantho = findViewById(R.id.manobkantho_cv);
        inkilab = findViewById(R.id.inkilab_cv);
        zugantor = findViewById(R.id.zugantor_cv);
        ittefak = findViewById(R.id.ittefak_cv);
        zuger_alo = findViewById(R.id.zuger_alo_cv);
        jonokantho = findViewById(R.id.jonokantho_cv);
        songram = findViewById(R.id.songram_cv);


        prothom_alo.setOnClickListener(this);
        kaler_kantho.setOnClickListener(this);
        somokal.setOnClickListener(this);
        noyadigonto.setOnClickListener(this);
        manobjomin.setOnClickListener(this);
        vorerkagoj.setOnClickListener(this);
        dinkal.setOnClickListener(this);
        zayzaydin.setOnClickListener(this);
        manobkantho.setOnClickListener(this);
        inkilab.setOnClickListener(this);
        zugantor.setOnClickListener(this);
        ittefak.setOnClickListener(this);
        zuger_alo.setOnClickListener(this);
        jonokantho.setOnClickListener(this);
        songram.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.prothom_alo_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            intent.putExtra("name","Altab Hossain Dulal");
            intent.putExtra("position","Prothom");
            intent.putExtra("discription","Staff Reporter");
            intent.putExtra("phone","0176292929");
            intent.putExtra("email","example@gmail.com");
            startActivity(intent);
        }
        if(v.getId()==R.id.kaler_kantho_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.somokal_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.noyadigonto_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.manobjomin_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.vorerkagoj_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.dinkal_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.zayzaydin_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.manobkantho_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.inkilab_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.zugantor_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.ittefak_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.zuger_alo_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.jonokantho_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }
        if(v.getId()==R.id.songram_cv){
            Intent intent = new Intent(getApplicationContext(), profile_person.class);
            startActivity(intent);
        }

    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}