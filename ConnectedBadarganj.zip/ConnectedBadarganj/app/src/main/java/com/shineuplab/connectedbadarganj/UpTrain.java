package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;


public class UpTrain extends Fragment {


    public UpTrain() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_down_train, container, false);

        ListView listView = view.findViewById(R.id.DownTrainListId);
        String[] listItem = getResources().getStringArray(R.array.UpTrainListArray);


        ArrayAdapter<String> listViewAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_activated_1, listItem);
        listView.setAdapter(listViewAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_421));
                    i.putExtra("trainName", getString(R.string.name_421));
                    i.putExtra("arrived", getString(R.string.arrived_421));
                    i.putExtra("stops", getString(R.string.stops_421));
                    i.putExtra("StartingPoint", getString(R.string.kurigram));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    startActivity(i);
                }
                if (position == 1) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_63));
                    i.putExtra("trainName", getString(R.string.name_63));
                    i.putExtra("arrived", getString(R.string.arrived_63));
                    i.putExtra("stops", getString(R.string.stops_63));
                    i.putExtra("StartingPoint", getString(R.string.lalmonirhat));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    startActivity(i);
                }
                if (position == 2) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_767));
                    i.putExtra("trainName", getString(R.string.name_767));
                    i.putExtra("arrived", getString(R.string.arrived_767));
                    i.putExtra("stops", getString(R.string.stops_767));
                    i.putExtra("StartingPoint", getString(R.string.santahar));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    startActivity(i);
                }
                if (position == 3) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_dc_1));
                    i.putExtra("trainName", getString(R.string.name_dc_1));
                    i.putExtra("arrived", getString(R.string.arrived_dc_1));
                    i.putExtra("stops", getString(R.string.stops_dc_1));
                    i.putExtra("StartingPoint", getString(R.string.lalmonirhat));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    startActivity(i);
                }
                if (position == 4) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_61));
                    i.putExtra("trainName", getString(R.string.name_61));
                    i.putExtra("arrived", getString(R.string.arrived_61));
                    i.putExtra("stops", getString(R.string.stops_61));
                    i.putExtra("StartingPoint", getString(R.string.lalmonirhat));
                    i.putExtra("EndPoint", getString(R.string.dinajpur));
                    startActivity(i);
                }
                if (position == 5) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_461));
                    i.putExtra("trainName", getString(R.string.name_421));
                    i.putExtra("arrived", getString(R.string.arrived_421));
                    i.putExtra("stops", getString(R.string.stops_421));
                    i.putExtra("StartingPoint", getString(R.string.kurigram));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    startActivity(i);
                }
            }
        });
        return view;
    }

}
