package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class up_profile extends AppCompatActivity {

    ImageView UpBg;
    LinearLayout UpWelcomeText, UpMenu;
    Animation frombottom;
    TextView UpNameTv;
    CardView UpChairman, UpMember, UpSecretary, UpOperator;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_profile);

        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);

        UpBg = findViewById(R.id.UpBg);
        UpWelcomeText = findViewById(R.id.UpWelcomeText);
        UpMenu = findViewById(R.id.UpMenu);
        UpNameTv = findViewById(R.id.UpNameTv);

        UpChairman = findViewById(R.id.UpChairman);
        UpMember = findViewById(R.id.UpMember);
        UpSecretary = findViewById(R.id.UpSecretary);
        UpOperator = findViewById(R.id.UpOperator);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            final String UpName = bundle.getString("up_name");
            UpNameTv.setText(UpName);

            final String Up6 = getString(R.string.up_chairman_6_name);


            UpChairman.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(getApplicationContext(), profile_person.class);
                    Bundle bundle = new Bundle();
                    bundle.putInt("proPic", R.drawable.uttom);
                    intent.putExtras(bundle);
                    intent.putExtra("name", getString(R.string.up_chairman_6_name));
                    intent.putExtra("position", getString(R.string.chairman));
                    intent.putExtra("description", getString(R.string.up_chairman_6_description));
                    intent.putExtra("phone", getString(R.string.up_chairman_6_phone));
                    intent.putExtra("email", getString(R.string.up_chairman_6_email));
                    startActivity(intent);

                }
            });


        }

        UpBg.animate().translationY(-1500).setDuration(1500).setStartDelay(300);
        UpWelcomeText.animate().translationY(-440).setDuration(1500).setStartDelay(300);

        // welcomeText.startAnimation(fromBottom);
        UpMenu.startAnimation(frombottom);

    }


    public void UpChairman(View view) {

    }

    public void UpMember(View view) {
    }

    public void UpSecretary(View view) {
    }

    public void UpOperator(View view) {
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(), Adv_private.class);
        startActivity(intent);
    }

}
