package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class EducationalOrganizationProfile extends AppCompatActivity {

    TextView NameTv, DiscriptionTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educational_organization_profile);

        NameTv = findViewById(R.id.NameTv);
        DiscriptionTv = findViewById(R.id.DiscriptionTv);


        Bundle bundle = getIntent().getExtras();

        if (bundle!=null){
            String Name = bundle.getString("name");
            String Description = bundle.getString("description");
            NameTv.setText(Name);
            DiscriptionTv.setText(Description);
        }
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
