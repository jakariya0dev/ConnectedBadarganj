package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class college extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college);
    }

    public void college_bgc(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_bgc));
        intent.putExtra("description",getString(R.string.college_bgc));
        startActivity(intent);
    }
    public void college_bwc(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_bwc));
        intent.putExtra("description",getString(R.string.college_bwc));
        startActivity(intent);
    }
    public void college_bakhshiganj(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_bakhshiganj));
        intent.putExtra("description",getString(R.string.college_bakhshiganj));
        startActivity(intent);
    }
    public void college_kutubpur(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_kutubpur));
        intent.putExtra("description",getString(R.string.college_kutubpur));
        startActivity(intent);
    }
    public void college_pirpal(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_pirpal));
        intent.putExtra("description",getString(R.string.college_pirpal));
        startActivity(intent);
    }
    public void college_vip(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_vip));
        intent.putExtra("description",getString(R.string.college_vip));
        startActivity(intent);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
