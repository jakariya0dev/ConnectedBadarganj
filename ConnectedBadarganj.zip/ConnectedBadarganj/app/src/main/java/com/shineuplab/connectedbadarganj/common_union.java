package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

public class common_union extends AppCompatActivity {

    CardView upCv6, upCv7, upCv8, upCv9, upCv10, upCv11, upCv12, upCv13, upCv14, upCv15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_union);

        upCv6 = findViewById(R.id.upCv6);
        upCv7 = findViewById(R.id.upCv7);
        upCv8 = findViewById(R.id.upCv8);
        upCv9 = findViewById(R.id.upCv9);
        upCv10 = findViewById(R.id.upCv10);
        upCv11 = findViewById(R.id.upCv11);
        upCv12 = findViewById(R.id.upCv12);
        upCv13 = findViewById(R.id.upCv13);
        upCv14 = findViewById(R.id.upCv14);
        upCv15 = findViewById(R.id.upCv15);

        upCv6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_6.class);
                startActivity(intent);
            }
        });
        upCv7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_7.class);
                startActivity(intent);
            }
        });
        upCv8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_8.class);
                startActivity(intent);
            }
        });
        upCv9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_9.class);
                startActivity(intent);
            }
        });
        upCv10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_10.class);
                startActivity(intent);
            }
        });
        upCv11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_11.class);
                startActivity(intent);
            }
        });
        upCv12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_12.class);
                startActivity(intent);
            }
        });
        upCv13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_13.class);
                startActivity(intent);
            }
        });
        upCv14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_14.class);
                startActivity(intent);
            }
        });
        upCv15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),up_15.class);
                startActivity(intent);
            }
        });

    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
