package com.shineuplab.connectedbadarganj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.ToxicBakery.viewpager.transforms.RotateUpTransformer;

public class personality extends FragmentActivity {

    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personality);

        viewPager = findViewById(R.id.viewPagerVip);
        FragmentManager fragmentManager = getSupportFragmentManager();
        customVipAdapter customAdapter = new customVipAdapter(fragmentManager);
        viewPager.setAdapter(customAdapter);
        viewPager.setPageTransformer(true, new RotateUpTransformer());


    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}

class customVipAdapter extends FragmentStatePagerAdapter {


    public customVipAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        Fragment fragment = null;

        if (position == 0) {
            fragment = new FragmentVipOne();
        }
        if (position == 1) {
            fragment = new FragmentVipTwo();
        }
        if (position == 2) {
            fragment = new FragmentVipThree();
        }
        if (position == 3) {
            fragment = new FragmentVipFour();
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 4;
    }
}
