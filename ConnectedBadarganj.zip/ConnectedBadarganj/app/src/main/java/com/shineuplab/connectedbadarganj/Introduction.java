package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Introduction extends AppCompatActivity {

    ExpandableListView expandableListView;
    CustomAdapter customAdapter;
    List<String> ListDataHeader;
    HashMap<String,List<String>> ListDataChild;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction);

        prepareData();

        expandableListView = findViewById(R.id.IntroExpandableListViewId);
        customAdapter = new CustomAdapter(this, ListDataHeader,ListDataChild);

        expandableListView.setAdapter(customAdapter);


    }

    public void prepareData(){
        String[] headerString = getResources().getStringArray(R.array.expandable_list_view_intro_header);
        String[] childString = getResources().getStringArray(R.array.expandable_list_view_intro_child);

        ListDataHeader = new ArrayList<>();
        ListDataChild = new HashMap<>();

        for (int i = 0; i < headerString.length; i++){

            ListDataHeader.add(headerString[i]);

            List<String> child = new ArrayList<>();
            child.add(childString[i]);

            ListDataChild.put(ListDataHeader.get(i),child);
        }

    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
