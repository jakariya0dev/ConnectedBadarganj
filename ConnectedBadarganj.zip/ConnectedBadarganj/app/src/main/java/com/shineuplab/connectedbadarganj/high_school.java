package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class high_school extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_school);
    }

    public void school_1(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_1));
        intent.putExtra("description",getString(R.string.high_school_description_1));
        startActivity(intent);
    }
    public void school_2(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_2));
        intent.putExtra("description",getString(R.string.high_school_description_2));
        startActivity(intent);
    }
    public void school_3(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_3));
        intent.putExtra("description",getString(R.string.high_school_description_3));
        startActivity(intent);
    }
    public void school_4(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_4));
        intent.putExtra("description",getString(R.string.high_school_description_4));
        startActivity(intent);
    }
    public void school_5(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_5));
        intent.putExtra("description",getString(R.string.high_school_description_5));
        startActivity(intent);
    }
    public void school_6(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_6));
        intent.putExtra("description",getString(R.string.high_school_description_6));
        startActivity(intent);
    }
    public void school_7(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_7));
        intent.putExtra("description",getString(R.string.high_school_description_7));
        startActivity(intent);
    }
    public void school_8(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_8));
        intent.putExtra("description",getString(R.string.high_school_description_8));
        startActivity(intent);
    }
    public void school_9(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_9));
        intent.putExtra("description",getString(R.string.high_school_description_9));
        startActivity(intent);
    }
    public void school_10(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_10));
        intent.putExtra("description",getString(R.string.high_school_description_10));
        startActivity(intent);
    }
    public void school_11(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_11));
        intent.putExtra("description",getString(R.string.high_school_description_11));
        startActivity(intent);
    }
    public void school_12(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_12));
        intent.putExtra("description",getString(R.string.high_school_description_12));
        startActivity(intent);
    }
    public void school_13(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_13));
        intent.putExtra("description",getString(R.string.high_school_description_13));
        startActivity(intent);
    }
    public void school_14(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_14));
        intent.putExtra("description",getString(R.string.high_school_description_14));
        startActivity(intent);
    }
    public void school_15(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_15));
        intent.putExtra("description",getString(R.string.high_school_description_15));
        startActivity(intent);
    }
    public void school_16(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_16));
        intent.putExtra("description",getString(R.string.high_school_description_16));
        startActivity(intent);
    }
    public void school_17(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_17));
        intent.putExtra("description",getString(R.string.high_school_description_17));
        startActivity(intent);
    }
    public void school_18(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_18));
        intent.putExtra("description",getString(R.string.high_school_description_18));
        startActivity(intent);
    }
    public void school_19(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_19));
        intent.putExtra("description",getString(R.string.high_school_description_19));
        startActivity(intent);
    }
    public void school_20(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_20));
        intent.putExtra("description",getString(R.string.high_school_description_20));
        startActivity(intent);
    }
    public void school_21(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_21));
        intent.putExtra("description",getString(R.string.high_school_description_21));
        startActivity(intent);
    }
    public void school_22(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_22));
        intent.putExtra("description",getString(R.string.high_school_description_22));
        startActivity(intent);
    }
    public void school_23(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_23));
        intent.putExtra("description",getString(R.string.high_school_description_23));
        startActivity(intent);
    }
    public void school_24(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_24));
        intent.putExtra("description",getString(R.string.high_school_description_24));
        startActivity(intent);
    }
    public void school_25(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_25));
        intent.putExtra("description",getString(R.string.high_school_description_25));
        startActivity(intent);
    }
    public void school_26(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_26));
        intent.putExtra("description",getString(R.string.high_school_description_26));
        startActivity(intent);
    }
    public void school_27(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.high_school_name_27));
        intent.putExtra("description",getString(R.string.high_school_description_27));
        startActivity(intent);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
