package com.shineuplab.connectedbadarganj;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;


public class train_time_table extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private CoordinatorLayout coordinatorLayout;
    Dialog trainPopupDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_train_time_table);

        trainPopupDialog = new Dialog(this);

        viewPager = findViewById(R.id.viewPager);
        createViewPager(viewPager);

        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        createTabIcons();

        coordinatorLayout = findViewById(R.id.train_coordinatorlayout);

        Snackbar snackbar = Snackbar.make(coordinatorLayout, R.string.trainSnackBarText, Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction(R.string.clickHere, new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                trainIntroPopup();

            }
        });


        snackbar.setActionTextColor(getResources().getColor(R.color.snackBarButtonColor));
        snackbar.show();

        View snackView = snackbar.getView();
        snackView.setBackgroundColor(getResources().getColor(R.color.snackBarBackgroundColor));
        TextView snackBarTextView = snackView.findViewById(com.google.android.material.R.id.snackbar_text);
        snackBarTextView.setTextColor(getResources().getColor(R.color.snackBarTextColor));

        Button snackBarButton = snackView.findViewById(com.google.android.material.R.id.snackbar_action);
        snackBarButton.setAllCaps(false);
        snackBarButton.setPadding(15, 1, 15, 1);
        snackBarButton.setBackground(getResources().getDrawable(R.drawable.doctor_button_background_white));
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    private void trainIntroPopup() {

        trainPopupDialog.setContentView(R.layout.train_intro_popup);
        ImageView closePopup = trainPopupDialog.findViewById(R.id.train_intro_close_id);
        closePopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                trainPopupDialog.dismiss();
            }
        });

        trainPopupDialog.show();
    }

    private void createTabIcons() {

        TextView tabOne = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        tabOne.setText(R.string.down_train);
        tabOne.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_arrow_downward_black_24dp, 0, 0);
        tabLayout.getTabAt(0).setCustomView(tabOne);

        TextView tabTwo = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        tabTwo.setText(R.string.up_train);
        tabTwo.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_arrow_upward_black_24dp, 0, 0);
        tabLayout.getTabAt(1).setCustomView(tabTwo);


    }

    private void createViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new DownTrain(), getResources().getString(R.string.down_train));
        adapter.addFrag(new UpTrain(), getResources().getString(R.string.up_train));
        viewPager.setAdapter(adapter);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

}
