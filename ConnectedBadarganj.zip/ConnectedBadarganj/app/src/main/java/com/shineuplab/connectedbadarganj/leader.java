package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class leader extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader);


    }


    public void mp(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.mp);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.mp_name));
        intent.putExtra("position",getString(R.string.mp_designation));
        intent.putExtra("description",getString(R.string.mp_description));
        intent.putExtra("phone",getString(R.string.mp_phone));
        intent.putExtra("email",getString(R.string.mp_email));
        startActivity(intent);
    }
    public void uz_chairman(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_chairman);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.uz_chairman_name));
        intent.putExtra("position",getString(R.string.uz_chairman_designation));
        intent.putExtra("description",getString(R.string.uz_chairman_description));
        intent.putExtra("phone",getString(R.string.uz_chairman_phone));
        intent.putExtra("email",getString(R.string.uz_chairman_email));
        startActivity(intent);
    }
    public void uz_vice_chairman(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_3_name));
        intent.putExtra("position",getString(R.string.word_no_3_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_3_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void uz_women_vice_chairman(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_4_name));
        intent.putExtra("position",getString(R.string.word_no_4_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_4_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void mayor(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.uttom);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.mayor_name));
        intent.putExtra("position",getString(R.string.mayor));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.mayor_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void up_chairman_6(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_6_name));
        intent.putExtra("position",getString(R.string.up_chairman_6_designation));
        intent.putExtra("description",getString(R.string.up_chairman_6_description));
        intent.putExtra("phone",getString(R.string.up_chairman_6_phone));
        intent.putExtra("email",getString(R.string.up_chairman_6_email));
        startActivity(intent);
    }
    public void up_chairman_7(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_seven);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_7_name));
        intent.putExtra("position",getString(R.string.up_chairman_7_designation));
        intent.putExtra("description",getString(R.string.up_chairman_7_description));
        intent.putExtra("phone",getString(R.string.up_chairman_7_phone));
        intent.putExtra("email",getString(R.string.up_chairman_7_email));
        startActivity(intent);
    }
    public void up_chairman_8(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_eight);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_8_name));
        intent.putExtra("position",getString(R.string.up_chairman_8_designation));
        intent.putExtra("description",getString(R.string.up_chairman_8_description));
        intent.putExtra("phone",getString(R.string.up_chairman_8_phone));
        intent.putExtra("email",getString(R.string.up_chairman_8_email));
        startActivity(intent);
    }
    public void up_chairman_9(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_nine);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_9_name));
        intent.putExtra("position",getString(R.string.up_chairman_9_designation));
        intent.putExtra("description",getString(R.string.up_chairman_9_description));
        intent.putExtra("phone",getString(R.string.up_chairman_9_phone));
        intent.putExtra("email",getString(R.string.up_chairman_9_email));
        startActivity(intent);
    }
    public void up_chairman_10(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_ten);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_10_name));
        intent.putExtra("position",getString(R.string.up_chairman_10_designation));
        intent.putExtra("description",getString(R.string.up_chairman_10_description));
        intent.putExtra("phone",getString(R.string.up_chairman_10_phone));
        intent.putExtra("email",getString(R.string.up_chairman_10_email));
        startActivity(intent);
    }
    public void up_chairman_11(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_eleven);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_11_name));
        intent.putExtra("position",getString(R.string.up_chairman_11_designation));
        intent.putExtra("description",getString(R.string.up_chairman_11_description));
        intent.putExtra("phone",getString(R.string.up_chairman_11_phone));
        intent.putExtra("email",getString(R.string.up_chairman_11_email));
        startActivity(intent);
    }
    public void up_chairman_12(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_twelve);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_12_name));
        intent.putExtra("position",getString(R.string.up_chairman_12_designation));
        intent.putExtra("description",getString(R.string.up_chairman_12_description));
        intent.putExtra("phone",getString(R.string.up_chairman_12_phone));
        intent.putExtra("email",getString(R.string.up_chairman_12_email));
        startActivity(intent);
    }
    public void up_chairman_13(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_thirtine);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_13_name));
        intent.putExtra("position",getString(R.string.up_chairman_13_designation));
        intent.putExtra("description",getString(R.string.up_chairman_13_description));
        intent.putExtra("phone",getString(R.string.up_chairman_13_phone));
        intent.putExtra("email",getString(R.string.up_chairman_13_email));
        startActivity(intent);
    }
    public void up_chairman_14(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_fourtine);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_14_name));
        intent.putExtra("position",getString(R.string.up_chairman_14_designation));
        intent.putExtra("description",getString(R.string.up_chairman_14_description));
        intent.putExtra("phone",getString(R.string.up_chairman_14_phone));
        intent.putExtra("email",getString(R.string.up_chairman_14_email));
        startActivity(intent);
    }
    public void up_chairman_15(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.up_fiften);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.up_chairman_15_name));
        intent.putExtra("position",getString(R.string.up_chairman_15_designation));
        intent.putExtra("description",getString(R.string.up_chairman_15_description));
        intent.putExtra("phone",getString(R.string.up_chairman_15_phone));
        intent.putExtra("email",getString(R.string.up_chairman_15_email));
        startActivity(intent);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

}
