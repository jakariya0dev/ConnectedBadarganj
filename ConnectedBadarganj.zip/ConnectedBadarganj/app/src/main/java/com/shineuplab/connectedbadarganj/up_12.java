package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class up_12 extends AppCompatActivity {

    CardView UpOperator, UpChairman;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_12);

        ImageView Pourobg;
        LinearLayout welcomeText, Menu;
        Animation frombottom;



        Pourobg = findViewById(R.id.UpBg);
        welcomeText = findViewById(R.id.UpWelcomeText);
        Menu = findViewById(R.id.UpMenu);

        UpChairman = findViewById(R.id.UpChairman);
        UpOperator = findViewById(R.id.UpOperator);

        UpChairman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), profile_person.class);
                Bundle bundle = new Bundle();
                bundle.putInt("proPic",R.drawable.up_twelve);
                intent.putExtras(bundle);
                intent.putExtra("name",getString(R.string.up_chairman_12_name));
                intent.putExtra("position",getString(R.string.up_chairman_12_designation));
                intent.putExtra("description",getString(R.string.up_chairman_12_description));
                intent.putExtra("phone",getString(R.string.up_chairman_12_phone));
                intent.putExtra("email",getString(R.string.up_chairman_12_email));
                startActivity(intent);
            }
        });

        UpOperator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), up_entraprenour.class);
                Bundle bundle = new Bundle();
                intent.putExtra("UpNameHeading",getString(R.string.up_chairman_12_description));
                intent.putExtra("nameOne",getString(R.string.up_entra_name_12));
                intent.putExtra("nameTwo",getString(R.string.up_wentra_name_12));
                intent.putExtra("phoneOne",getString(R.string.up_entra_phone_12));
                intent.putExtra("phoneTwo",getString(R.string.up_wentra_phone_12));
                intent.putExtra("emailOne",getString(R.string.up_entra_email_12));
                intent.putExtra("emailTwo",getString(R.string.up_wentra_email_12));
                startActivity(intent);
            }
        });


        // Animation
        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);
        Pourobg.animate().translationY(-1500).setDuration(1500).setStartDelay(300);
        welcomeText.animate().translationY(-440).setDuration(1500).setStartDelay(300);
        Menu.startAnimation(frombottom);

    }
}
