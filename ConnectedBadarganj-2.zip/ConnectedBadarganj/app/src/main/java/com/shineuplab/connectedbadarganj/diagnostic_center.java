package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class diagnostic_center extends AppCompatActivity implements View.OnClickListener {

    CardView MhCv, HealthCareCv, DrMokhlecherCv;

    Button popular_1, popular_2, popular_3, popular_4, popular_5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnostic_center);

        MhCv = findViewById(R.id.MhCv);
        HealthCareCv = findViewById(R.id.HealthCareCv);
        DrMokhlecherCv  = findViewById(R.id.DrMokhlecherCv);

        popular_1  = findViewById(R.id.popular_1);
        popular_2 = findViewById(R.id.popular_2);
        popular_3  = findViewById(R.id.popular_3);
        popular_4  = findViewById(R.id.popular_4);
        popular_5  = findViewById(R.id.popular_5);

        popular_1.setOnClickListener(this);
        popular_2.setOnClickListener(this);
        popular_3.setOnClickListener(this);
        popular_4.setOnClickListener(this);
        popular_5.setOnClickListener(this);

        MhCv.setOnClickListener(this);
        HealthCareCv.setOnClickListener(this);
        DrMokhlecherCv.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.MhCv){
            Intent intent = new Intent(getApplicationContext(), mh_diagnostic.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.HealthCareCv){
            Intent intent = new Intent(getApplicationContext(), healthCare.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.DrMokhlecherCv){
            Intent intent = new Intent(getApplicationContext(), dc_mokhlechar.class);
            startActivity(intent);
        }

        if (v.getId()==R.id.popular_1||v.getId()==R.id.popular_2||v.getId()==R.id.popular_3||
                v.getId()==R.id.popular_4||v.getId()==R.id.popular_5){

            AlertDialog.Builder AlertDialog = new AlertDialog.Builder(this);
            AlertDialog.setMessage(getResources().getString(R.string.not_working_notice));
            AlertDialog.setPositiveButton("OK", null);
            AlertDialog.create().show();

        }
/*
        if (v.getId()==R.id.popular_1){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        }
        if (v.getId()==R.id.OishiCv){
            Intent intent = new Intent(getApplicationContext(),healthCare.class);
            startActivity(intent);
        }
 */

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
