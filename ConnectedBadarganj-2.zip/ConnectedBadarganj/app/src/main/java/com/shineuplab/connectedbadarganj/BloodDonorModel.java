package com.shineuplab.connectedbadarganj;

public class BloodDonorModel {

    private String name, blood_group, phone;

    public BloodDonorModel() {

    }

    public BloodDonorModel(String name, String blood_group, String phone) {
        this.name = name;
        this.blood_group = blood_group;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
