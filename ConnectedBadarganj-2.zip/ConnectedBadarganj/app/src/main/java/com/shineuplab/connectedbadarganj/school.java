package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class school extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school);
    }
    public void jr_school_1(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.school_name_1));
        intent.putExtra("description",getString(R.string.school_description_1));
        startActivity(intent);
    }
    public void jr_school_2(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.school_name_2));
        intent.putExtra("description",getString(R.string.school_description_2));
        startActivity(intent);
    }
    public void jr_school_3(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.school_name_3));
        intent.putExtra("description",getString(R.string.school_description_3));
        startActivity(intent);
    }
    public void jr_school_4(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.school_name_4));
        intent.putExtra("description",getString(R.string.school_description_4));
        startActivity(intent);
    }
    public void jr_school_5(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.school_name_5));
        intent.putExtra("description",getString(R.string.school_description_5));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

}
