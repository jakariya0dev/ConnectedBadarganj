package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class pouro_employee extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pouro_employee);
    }

    public void adminCvOne(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_admin_one);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Administrative_Division1_name));
        intent.putExtra("position",getString(R.string.Administrative_Division1_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Administrative_Division1_phone));
        intent.putExtra("email",getString(R.string.Administrative_Division1_email));
        startActivity(intent);
    }
    public void adminCvTwo(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_admin_two);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Administrative_Division2_name));
        intent.putExtra("position",getString(R.string.Administrative_Division2_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Administrative_Division2_phone));
        intent.putExtra("email",getString(R.string.Administrative_Division2_email));
        startActivity(intent);
    }
    public void adminCvThree(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_admin_three);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Administrative_Division3_name));
        intent.putExtra("position",getString(R.string.Administrative_Division3_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Administrative_Division3_phone));
        intent.putExtra("email",getString(R.string.Administrative_Division3_email));
        startActivity(intent);
    }
    public void adminCvFour(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_admin_four);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Administrative_Division4_name));
        intent.putExtra("position",getString(R.string.Administrative_Division4_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Administrative_Division4_phone));
        intent.putExtra("email",getString(R.string.Administrative_Division4_email));
        startActivity(intent);
    }

    public void engineerCvOne(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_eng_one);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Engineering_Division1_name));
        intent.putExtra("position",getString(R.string.Engineering_Division1_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Engineering_Division1_phone));
        intent.putExtra("email",getString(R.string.Engineering_Division1_email));
        startActivity(intent);
    }
    public void engineerCvTwo(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_eng_two);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Engineering_Division2_name));
        intent.putExtra("position",getString(R.string.Engineering_Division2_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Engineering_Division2_phone));
        intent.putExtra("email",getString(R.string.Engineering_Division2_email));
        startActivity(intent);
    }
    public void engineerCvThree(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_eng_three);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Engineering_Division3_name));
        intent.putExtra("position",getString(R.string.Engineering_Division3_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Engineering_Division3_phone));
        intent.putExtra("email",getString(R.string.Engineering_Division3_email));
        startActivity(intent);
    }
    public void engineerCvFour(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_eng_four);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Engineering_Division4_name));
        intent.putExtra("position",getString(R.string.Engineering_Division4_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Engineering_Division4_phone));
        intent.putExtra("email",getString(R.string.Engineering_Division4_email));
        startActivity(intent);
    }
    public void engineerCvFive(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.pouro_eng_five);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.Engineering_Division5_name));
        intent.putExtra("position",getString(R.string.Engineering_Division5_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.Engineering_Division5_phone));
        intent.putExtra("email",getString(R.string.Engineering_Division5_email));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

}
