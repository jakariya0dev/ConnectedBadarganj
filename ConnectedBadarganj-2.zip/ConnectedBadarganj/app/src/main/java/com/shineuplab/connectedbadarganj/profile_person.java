package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.auth.FirebaseAuth;

import de.hdodenhof.circleimageview.CircleImageView;

public class profile_person extends AppCompatActivity {

    CircleImageView ProPicIv;
    TextView NameTv, PositionTv, DiscriptionTv, PhoneTv, EmailTv;
    CardView callButton, smsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_person);

        ProPicIv = findViewById(R.id.ProPicIv);

        NameTv = findViewById(R.id.NameTv);
        PositionTv = findViewById(R.id.PositionTv);
        DiscriptionTv = findViewById(R.id.DiscriptionTv);
        PhoneTv = findViewById(R.id.PhoneTv);
        EmailTv = findViewById(R.id.EmailTv);

        callButton = findViewById(R.id.callBtn);
        smsButton = findViewById(R.id.smsBtn);

        Bundle bundle = getIntent().getExtras();

        if (bundle!=null){

            int proPic = bundle.getInt("proPic");
            String Name = bundle.getString("name");
            String Position = bundle.getString("position");
            String Description = bundle.getString("description");
            String Phone = bundle.getString("phone");
            String Email = bundle.getString("email");
            ProPicIv.setImageResource(proPic);
            NameTv.setText(Name);
            PositionTv.setText(Position);
            DiscriptionTv.setText(Description);
            PhoneTv.setText(Phone);
            EmailTv.setText(Email);
        }

        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = PhoneTv.getText().toString();
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+phoneNumber));
                startActivity(intent);
            }
        });
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = PhoneTv.getText().toString();
                Intent smsIntent = new Intent(Intent.ACTION_VIEW);
                smsIntent.setType("vnd.android-dir/mms-sms");
                smsIntent.putExtra("address", phoneNumber);
                smsIntent.putExtra("sms_body","");
                startActivity(smsIntent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
