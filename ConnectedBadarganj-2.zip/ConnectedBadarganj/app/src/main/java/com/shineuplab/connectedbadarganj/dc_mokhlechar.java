package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class dc_mokhlechar extends AppCompatActivity implements View.OnClickListener {
    CardView dcMokhlecharCv_1, dcMokhlecharCv_2, dcMokhlecharCv_3, dcMokhlecharCv_4, dcMokhlecharCv_5, dcMokhlecharCv_6, dcMokhlecharCv_7, dcMokhlecharCv_8, dcMokhlecharCv_9, dcMokhlecharCv_10, dcMokhlecharCv_11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dc_mokhlechar);



        dcMokhlecharCv_1 = findViewById(R.id.dcMokhlecharCv_1);
        dcMokhlecharCv_2 = findViewById(R.id.dcMokhlecharCv_2);
        dcMokhlecharCv_3 = findViewById(R.id.dcMokhlecharCv_3);
        dcMokhlecharCv_4 = findViewById(R.id.dcMokhlecharCv_4);
        dcMokhlecharCv_5 = findViewById(R.id.dcMokhlecharCv_5);
        dcMokhlecharCv_6 = findViewById(R.id.dcMokhlecharCv_6);
        dcMokhlecharCv_7 = findViewById(R.id.dcMokhlecharCv_7);
        dcMokhlecharCv_8 = findViewById(R.id.dcMokhlecharCv_8);
        dcMokhlecharCv_9 = findViewById(R.id.dcMokhlecharCv_9);
        dcMokhlecharCv_10 = findViewById(R.id.dcMokhlecharCv_10);
        dcMokhlecharCv_11 = findViewById(R.id.dcMokhlecharCv_11);

        dcMokhlecharCv_1.setOnClickListener(this);
        dcMokhlecharCv_2.setOnClickListener(this);
        dcMokhlecharCv_3.setOnClickListener(this);
        dcMokhlecharCv_4.setOnClickListener(this);
        dcMokhlecharCv_5.setOnClickListener(this);
        dcMokhlecharCv_6.setOnClickListener(this);
        dcMokhlecharCv_7.setOnClickListener(this);
        dcMokhlecharCv_8.setOnClickListener(this);
        dcMokhlecharCv_9.setOnClickListener(this);
        dcMokhlecharCv_10.setOnClickListener(this);
        dcMokhlecharCv_11.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()== R.id.dcMokhlecharCv_1){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_medicine_name_1));
            intent.putExtra("details", getString(R.string.m_medicine_details_1));
            intent.putExtra("time", getString(R.string.m_medicine_time_1));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_2){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_medicine_name_2));
            intent.putExtra("details", getString(R.string.m_medicine_details_2));
            intent.putExtra("time", getString(R.string.m_medicine_time_2));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_3){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_medicine_name_3));
            intent.putExtra("details", getString(R.string.m_medicine_details_3));
            intent.putExtra("time", getString(R.string.m_medicine_time_3));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_4){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_medicine_name_4));
            intent.putExtra("details", getString(R.string.m_medicine_details_4));
            intent.putExtra("time", getString(R.string.m_medicine_time_4));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_5){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_medicine_name_5));
            intent.putExtra("details", getString(R.string.m_medicine_details_5));
            intent.putExtra("time", getString(R.string.m_medicine_time_5));
            intent.putExtra("speciality", getString(R.string.Medicine_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_6){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_gynecologist_name_1));
            intent.putExtra("details", getString(R.string.m_gynecologist_details_1));
            intent.putExtra("time", getString(R.string.m_gynecologist_time_1));
            intent.putExtra("speciality", getString(R.string.Gynecologists_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_7){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_Pediatricians_name_1));
            intent.putExtra("details", getString(R.string.m_Pediatricians_details_1));
            intent.putExtra("time", getString(R.string.m_Pediatricians_time_1));
            intent.putExtra("speciality", getString(R.string.Pediatricians_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_8){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_Pediatricians_name_2));
            intent.putExtra("details", getString(R.string.m_Pediatricians_details_2));
            intent.putExtra("time", getString(R.string.m_Pediatricians_time_2));
            intent.putExtra("speciality", getString(R.string.Pediatricians_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_9){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_Paralysis_name_1));
            intent.putExtra("details", getString(R.string.m_Paralysis_details_1));
            intent.putExtra("time", getString(R.string.m_Paralysis_time_1));
            intent.putExtra("speciality", getString(R.string.Paralysis_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_10){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_Paralysis_name_2));
            intent.putExtra("details", getString(R.string.m_Paralysis_details_2));
            intent.putExtra("time", getString(R.string.m_Paralysis_time_2));
            intent.putExtra("speciality", getString(R.string.Paralysis_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
        if(v.getId()== R.id.dcMokhlecharCv_11){
            Intent intent = new Intent(getApplicationContext(), doctorProfile.class);
            intent.putExtra("name", getString(R.string.m_ent_name_1));
            intent.putExtra("details", getString(R.string.m_ent_details_1));
            intent.putExtra("time", getString(R.string.m_ent_time_1));
            intent.putExtra("speciality", getString(R.string.ent_sp));
            intent.putExtra("serial", getString(R.string.m_serial));
            startActivity(intent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
