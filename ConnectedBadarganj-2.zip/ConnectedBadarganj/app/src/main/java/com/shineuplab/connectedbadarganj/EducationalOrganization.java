package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class EducationalOrganization extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educational_organization);


    }

    public void college(View view) {
        Intent intent = new Intent(getApplicationContext(),college.class);
        startActivity(intent);
    }

    public void school_and_college(View view) {
        Intent intent = new Intent(getApplicationContext(),school_and_college.class);
        startActivity(intent);
    }

    public void high_school(View view) {
        Intent intent = new Intent(getApplicationContext(),high_school.class);
        startActivity(intent);
    }

    public void school(View view) {
        Intent intent = new Intent(getApplicationContext(),school.class);
        startActivity(intent);
    }

    public void kinder_garden(View view) {
        Intent intent = new Intent(getApplicationContext(),kinder_garden.class);
        startActivity(intent);
    }

    public void fazil_madrasah(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.fazil_madrasah_name_1));
        intent.putExtra("description",getString(R.string.fazil_madrasah_description_1));
        startActivity(intent);
    }

    public void alim_madrasah(View view) {
        Intent intent = new Intent(getApplicationContext(),alim_madrasah.class);
        startActivity(intent);
    }

    public void dakhil_madrasah(View view) {
        Intent intent = new Intent(getApplicationContext(),dakhil_madrasah.class);
        startActivity(intent);
    }

    public void ebtedayee_madrasah(View view) {
        AlertDialog.Builder AlertDialog = new AlertDialog.Builder(this);
        AlertDialog.setMessage(getResources().getString(R.string.not_working_notice));
        AlertDialog.setPositiveButton("OK", null);
        AlertDialog.create().show();
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
