package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class fazil_madrasah extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fazil_madrasah);
    }

    public void fazil_madrasah_1(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.fazil_madrasah_name_1));
        intent.putExtra("description",getString(R.string.fazil_madrasah_description_1));
        startActivity(intent);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
