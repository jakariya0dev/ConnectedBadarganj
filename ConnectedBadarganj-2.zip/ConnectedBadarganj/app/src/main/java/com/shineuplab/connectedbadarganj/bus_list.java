package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class bus_list extends AppCompatActivity implements View.OnClickListener {

    CardView haque, nabil, arafat, imran;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_list);

        haque = findViewById(R.id.haque);
        nabil = findViewById(R.id.nabil);
        arafat = findViewById(R.id.arafat);
        imran = findViewById(R.id.imran);

        haque.setOnClickListener(this);
        nabil.setOnClickListener(this);
        arafat.setOnClickListener(this);
        imran.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId()==R.id.haque){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.hauqe));
            intent.putExtra("phone", getResources().getString(R.string.haque_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.haque_counter));
            intent.putExtra("time", getResources().getString(R.string.haque_counter_time));
            startActivity(intent);
        }
        if (v.getId()==R.id.nabil){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.nabil));
            intent.putExtra("phone", getResources().getString(R.string.nabil_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.nabil_counter));
            intent.putExtra("time", getResources().getString(R.string.nabil_counter_time));
            startActivity(intent);

        }
        if (v.getId()==R.id.arafat){

            AlertDialog.Builder AlertDialog = new AlertDialog.Builder(this);
            AlertDialog.setMessage(getResources().getString(R.string.arafat_details));
            AlertDialog.setPositiveButton("OK", null);
            AlertDialog.create().show();

        }
        if (v.getId()==R.id.imran){

            Intent intent = new Intent(getApplicationContext(),bus.class);
            intent.putExtra("name", getResources().getString(R.string.imran));
            intent.putExtra("phone", getResources().getString(R.string.imran_counter_phone));
            intent.putExtra("counter", getResources().getString(R.string.imran_counter));
            intent.putExtra("time", getResources().getString(R.string.imran_counter_time));
            startActivity(intent);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
