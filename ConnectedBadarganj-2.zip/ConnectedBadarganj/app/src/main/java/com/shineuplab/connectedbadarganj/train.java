package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;


public class train extends AppCompatActivity {

    TextView TrainNoTv, NameTv, timeTv, StartingPointTv, EndPointTv, StopsTv, OffDayTv;
    //LinearLayout OfflineAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_train);

        TrainNoTv = findViewById(R.id.TrainNoTv);
        NameTv = findViewById(R.id.FirstNameTv);
        timeTv = findViewById(R.id.timeTv);
        StartingPointTv = findViewById(R.id.StartingPointTv);
        EndPointTv = findViewById(R.id.EndPointTv);
        StopsTv = findViewById(R.id.StopsTv);
        OffDayTv = findViewById(R.id.offDayTv);

        //OfflineAdd = findViewById(R.id.OfflineAdd);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            String trainNo = bundle.getString("trainNo");
            String trainName = bundle.getString("trainName");
            String arrived = bundle.getString("arrived");
            String stops = bundle.getString("stops");
            String startingPoint = bundle.getString("StartingPoint");
            String endPoint = bundle.getString("EndPoint");
            String offDayTv = bundle.getString("offDayTv");

            TrainNoTv.setText(trainNo);
            NameTv.setText(trainName);
            timeTv.setText(arrived);
            StopsTv.setText(stops);
            StartingPointTv.setText(startingPoint);
            EndPointTv.setText(endPoint);
            OffDayTv.setText(offDayTv);

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}

