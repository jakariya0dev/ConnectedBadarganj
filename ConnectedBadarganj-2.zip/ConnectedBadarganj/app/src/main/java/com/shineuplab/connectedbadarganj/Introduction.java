package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Introduction extends AppCompatActivity {

    ExpandableListView expandableListView;
    CustomAdapter customAdapter;
    List<String> ListDataHeader;
    HashMap<String,List<String>> ListDataChild;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction);

        prepareData();

        expandableListView = findViewById(R.id.IntroExpandableListViewId);
        customAdapter = new CustomAdapter(this, ListDataHeader,ListDataChild);

        expandableListView.setAdapter(customAdapter);


    }

    public void prepareData(){
        String[] headerString = getResources().getStringArray(R.array.expandable_list_view_intro_header);
        String[] childString = getResources().getStringArray(R.array.expandable_list_view_intro_child);

        ListDataHeader = new ArrayList<>();
        ListDataChild = new HashMap<>();

        for (int i = 0; i < headerString.length; i++){

            ListDataHeader.add(headerString[i]);

            List<String> child = new ArrayList<>();
            child.add(childString[i]);

            ListDataChild.put(ListDataHeader.get(i),child);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
