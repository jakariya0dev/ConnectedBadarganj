package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class govt_employee_profile extends AppCompatActivity {

    TextView NameTv, PositionTv, DescriptionTv, EmailTv, MobileTv, PhoneTv;
    ImageButton MobileBtn, PhoneBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_govt_employee_profile);

        NameTv = findViewById(R.id.NameTv);
        PositionTv = findViewById(R.id.PositionTv);
        DescriptionTv = findViewById(R.id.DescriptionTv);
        EmailTv  = findViewById(R.id.EmailTv);
        MobileTv  = findViewById(R.id.MobileTv);
        PhoneTv = findViewById(R.id.PhoneTv);

        MobileBtn = findViewById(R.id.MobileBtn);
        PhoneBtn = findViewById(R.id.PhoneBtn);

        NameTv.setText(getIntent().getExtras().getString("name"));
        PositionTv.setText(getIntent().getExtras().getString("designation"));
        DescriptionTv.setText(getIntent().getExtras().getString("description"));
        EmailTv.setText(getIntent().getExtras().getString("email"));
        MobileTv.setText(getIntent().getExtras().getString("mobile"));
        PhoneTv.setText(getIntent().getExtras().getString("phone"));

        MobileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+MobileTv.getText().toString().trim()));
                startActivity(intent);
            }
        });

        PhoneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+PhoneTv.getText().toString().trim()));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
