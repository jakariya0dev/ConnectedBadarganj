package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.firebase.auth.FirebaseAuth;

public class up_9 extends AppCompatActivity {

    CardView UpChairman, UpOperator, UpMember, UpSecretary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_9);

        ImageView Pourobg;
        LinearLayout welcomeText, Menu;
        Animation frombottom;


        Pourobg = findViewById(R.id.UpBg9);
        welcomeText = findViewById(R.id.UpWelcomeText9);
        Menu = findViewById(R.id.UpMenu9);
        UpChairman = findViewById(R.id.UpChairman9);
        UpOperator = findViewById(R.id.UpOperator9);
        UpMember = findViewById(R.id.UpMember9);
        UpSecretary = findViewById(R.id.UpSecretary9);

        UpChairman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), profile_person.class);
                Bundle bundle = new Bundle();
                bundle.putInt("proPic",R.drawable.up_nine);
                intent.putExtras(bundle);
                intent.putExtra("name",getString(R.string.up_chairman_9_name));
                intent.putExtra("position",getString(R.string.up_chairman_9_designation));
                intent.putExtra("description",getString(R.string.up_chairman_9_description));
                intent.putExtra("phone",getString(R.string.up_chairman_9_phone));
                intent.putExtra("email",getString(R.string.up_chairman_9_email));
                startActivity(intent);
            }
        });

        UpOperator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), up_entraprenour.class);
                intent.putExtra("UpNameHeading",getString(R.string.up_chairman_9_description));
                intent.putExtra("nameOne",getString(R.string.up_entra_name_9));
                intent.putExtra("nameTwo",getString(R.string.up_wentra_name_9));
                intent.putExtra("phoneOne",getString(R.string.up_entra_phone_9));
                intent.putExtra("phoneTwo",getString(R.string.up_wentra_phone_9));
                intent.putExtra("emailOne",getString(R.string.up_entra_email_9));
                intent.putExtra("emailTwo",getString(R.string.up_wentra_email_9));
                startActivity(intent);
            }
        });

        UpSecretary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), profile_person.class);
                Bundle bundle = new Bundle();
                bundle.putInt("proPic",R.drawable.man);
                intent.putExtras(bundle);
                intent.putExtra("name",getString(R.string.up_9_secretary_name));
                intent.putExtra("position",getString(R.string.up_secretary2));
                intent.putExtra("description",getString(R.string.up_chairman_9_description));
                intent.putExtra("phone",getString(R.string.up_9_secretary_phone));
                intent.putExtra("email",getString(R.string.up_chairman_9_email));
                startActivity(intent);
            }
        });

        UpMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), up_member.class);

                intent.putExtra(Variable.UpMemberHeadingTv, getString(R.string.up_chairman_9_description));

                intent.putExtra(Variable.upMemberName1, getString(R.string.up_9_member_name_1));
                intent.putExtra(Variable.upMemberName2, getString(R.string.up_9_member_name_2));
                intent.putExtra(Variable.upMemberName3, getString(R.string.up_9_member_name_3));
                intent.putExtra(Variable.upMemberName4, getString(R.string.up_9_member_name_4));
                intent.putExtra(Variable.upMemberName5, getString(R.string.up_9_member_name_5));
                intent.putExtra(Variable.upMemberName6, getString(R.string.up_9_member_name_6));
                intent.putExtra(Variable.upMemberName7, getString(R.string.up_9_member_name_7));
                intent.putExtra(Variable.upMemberName8, getString(R.string.up_9_member_name_8));
                intent.putExtra(Variable.upMemberName9, getString(R.string.up_9_member_name_9));
                intent.putExtra(Variable.upMemberName10, getString(R.string.up_9_member_name_123));
                intent.putExtra(Variable.upMemberName11, getString(R.string.up_9_member_name_456));
                intent.putExtra(Variable.upMemberName12, getString(R.string.up_9_member_name_789));

                intent.putExtra(Variable.upMemberPhone1, getString(R.string.up_9_member_phone_1));
                intent.putExtra(Variable.upMemberPhone2, getString(R.string.up_9_member_phone_2));
                intent.putExtra(Variable.upMemberPhone3, getString(R.string.up_9_member_phone_3));
                intent.putExtra(Variable.upMemberPhone4, getString(R.string.up_9_member_phone_4));
                intent.putExtra(Variable.upMemberPhone5, getString(R.string.up_9_member_phone_5));
                intent.putExtra(Variable.upMemberPhone6, getString(R.string.up_9_member_phone_6));
                intent.putExtra(Variable.upMemberPhone7, getString(R.string.up_9_member_phone_7));
                intent.putExtra(Variable.upMemberPhone8, getString(R.string.up_9_member_phone_8));
                intent.putExtra(Variable.upMemberPhone9, getString(R.string.up_9_member_phone_9));
                intent.putExtra(Variable.upMemberPhone10, getString(R.string.up_9_member_phone_123));
                intent.putExtra(Variable.upMemberPhone11, getString(R.string.up_9_member_phone_456));
                intent.putExtra(Variable.upMemberPhone12, getString(R.string.up_9_member_phone_789));
                startActivity(intent);
            }
        });
        // Animation
        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);
        Pourobg.animate().translationY(-1500).setDuration(1500).setStartDelay(300);
        welcomeText.animate().translationY(-440).setDuration(1500).setStartDelay(300);
        Menu.startAnimation(frombottom);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
