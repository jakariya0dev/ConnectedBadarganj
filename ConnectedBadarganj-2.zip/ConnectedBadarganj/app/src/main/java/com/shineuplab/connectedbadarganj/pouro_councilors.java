package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class pouro_councilors extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pouro_councilors);
    }

    public void councilorItem01(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_1_name));
        intent.putExtra("position",getString(R.string.word_no_1_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_1_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem02(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_2_name));
        intent.putExtra("position",getString(R.string.word_no_2_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_2_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem03(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_3_name));
        intent.putExtra("position",getString(R.string.word_no_3_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_3_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem04(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_4_name));
        intent.putExtra("position",getString(R.string.word_no_4_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_4_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem05(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_5_name));
        intent.putExtra("position",getString(R.string.word_no_5_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_5_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem06(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_6_name));
        intent.putExtra("position",getString(R.string.word_no_6_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_6_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem07(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_7_name));
        intent.putExtra("position",getString(R.string.word_no_7_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_7_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem08(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_8_name));
        intent.putExtra("position",getString(R.string.word_no_8_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_8_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem09(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_9_name));
        intent.putExtra("position",getString(R.string.word_no_9_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_9_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem123(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_123_name));
        intent.putExtra("position",getString(R.string.councilor));
        intent.putExtra("description",getString(R.string.word_no_123_designation));
        intent.putExtra("phone",getString(R.string.word_no_123_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem456(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_456_name));
        intent.putExtra("position",getString(R.string.word_no_456_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_456_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }
    public void councilorItem789(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_789_name));
        intent.putExtra("position",getString(R.string.word_no_789_designation));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_789_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
