package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.firebase.auth.FirebaseAuth;

public class Spectacular_place extends AppCompatActivity {

    BottomSheetBehavior bottomSheetBehavior;
    TextView bottomTv;
    ImageView SpInfoOne, SpInfoTwo, SpInfoThree, SpInfoFour, SpInfoFive;
    ImageView dismiss;
    View bottomSheet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spectacular_place);

        bottomSheet = findViewById(R.id.bottom_top_sheet);
        bottomTv = findViewById(R.id.bottomTv);
        SpInfoOne = findViewById(R.id.SpInfoOne);
        SpInfoTwo = findViewById(R.id.SpInfoTwo);
        SpInfoThree = findViewById(R.id.SpInfoThree);
        SpInfoFour = findViewById(R.id.SpInfoFour);
        SpInfoFive = findViewById(R.id.SpInfoFive);
        dismiss = findViewById(R.id.dismiss);

        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });
        SpInfoOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomTv.setText(R.string.sp_details_1);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        SpInfoTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomTv.setText(R.string.sp_details_2);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        SpInfoThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomTv.setText(R.string.sp_details_3);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        SpInfoFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomTv.setText(R.string.sp_details_4);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        SpInfoFive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomTv.setText(R.string.sp_details_5);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(), Adv_private.class);
        startActivity(intent);
    }
}
