package com.shineuplab.connectedbadarganj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class BloodDonor extends AppCompatActivity {

    EditText EmailEditText, PasswordEditText;
    Button LoginButton, SignUpBtn;
    ProgressBar LoginProgressBar;

    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_donor);

        EmailEditText = findViewById(R.id.loginEmailEditText);
        PasswordEditText = findViewById(R.id.loginPasswordEditText);
        LoginButton = findViewById(R.id.LoginBtnId);
        SignUpBtn = findViewById(R.id.signUpBtnId);
        LoginProgressBar = findViewById(R.id.LoginProgressBar);

        mAuth = FirebaseAuth.getInstance();

        SignUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),BloodDonorRegForm.class);
                startActivity(i);
            }
        });

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = EmailEditText.getText().toString().trim();
                String password = PasswordEditText.getText().toString().trim();

                if (email.isEmpty()) {
                    EmailEditText.setError("Enter an User Name");
                    EmailEditText.requestFocus();
                    return;
                }
                if (password.isEmpty()) {
                    PasswordEditText.setError("Enter a Password");
                    PasswordEditText.requestFocus();
                    return;
                }
                if (password.length() < 6) {
                    PasswordEditText.setError("Password must be 6 Charectar or more");
                    PasswordEditText.requestFocus();
                    return;
                }
                LoginProgressBar.setVisibility(View.VISIBLE);


                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Intent intent = new Intent(getApplicationContext(), BloodDonorDashboard.class);
                            startActivity(intent);
                            LoginProgressBar.setVisibility(View.GONE);

                        } else {
                            Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            LoginProgressBar.setVisibility(View.GONE);
                        }
                    }
                });


            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
