package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class up_member extends AppCompatActivity implements View.OnClickListener {

    TextView UpMemberHeadingTv, UpMemberName1,UpMemberName2,UpMemberName3,UpMemberName4,UpMemberName5,UpMemberName6,UpMemberName7,UpMemberName8,UpMemberName9,UpMemberName123,UpMemberName456,UpMemberName789;
    TextView UpMemberPhone1,UpMemberPhone2,UpMemberPhone3,UpMemberPhone4,UpMemberPhone5,UpMemberPhone6,UpMemberPhone7,UpMemberPhone8,UpMemberPhone9,UpMemberPhone123,UpMemberPhone456,UpMemberPhone789;
    ImageButton UpMemberPhoneButton1, UpMemberPhoneButton2, UpMemberPhoneButton3, UpMemberPhoneButton4, UpMemberPhoneButton5, UpMemberPhoneButton6, UpMemberPhoneButton7, UpMemberPhoneButton8, UpMemberPhoneButton9, UpMemberPhoneButton123, UpMemberPhoneButton456, UpMemberPhoneButton789;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_member);

        UpMemberHeadingTv = findViewById(R.id.UpMemberHeadingTv);
        UpMemberName1 = findViewById(R.id.UpMemberName1);
        UpMemberName2 = findViewById(R.id.UpMemberName2);
        UpMemberName3 = findViewById(R.id.UpMemberName3);
        UpMemberName4 = findViewById(R.id.UpMemberName4);
        UpMemberName5  = findViewById(R.id.UpMemberName5);
        UpMemberName6  = findViewById(R.id.UpMemberName6);
        UpMemberName7  = findViewById(R.id.UpMemberName7);
        UpMemberName8 = findViewById(R.id.UpMemberName8);
        UpMemberName9  = findViewById(R.id.UpMemberName9);
        UpMemberName123  = findViewById(R.id.UpMemberNameTv123);
        UpMemberName456  = findViewById(R.id.UpMemberNameTv456);
        UpMemberName789  = findViewById(R.id.UpMemberNameTv789);

        UpMemberPhone1 = findViewById(R.id.UpMemberPhone1);
        UpMemberPhone2 = findViewById(R.id.UpMemberPhone2);
        UpMemberPhone3 = findViewById(R.id.UpMemberPhone3);
        UpMemberPhone4 = findViewById(R.id.UpMemberPhone4);
        UpMemberPhone5 = findViewById(R.id.UpMemberPhone5);
        UpMemberPhone6 = findViewById(R.id.UpMemberPhone6);
        UpMemberPhone7 = findViewById(R.id.UpMemberPhone7);
        UpMemberPhone8 = findViewById(R.id.UpMemberPhone8);
        UpMemberPhone9 = findViewById(R.id.UpMemberPhone9);
        UpMemberPhone123  = findViewById(R.id.UpMemberPhoneTv123);
        UpMemberPhone456  = findViewById(R.id.UpMemberPhoneTv456);
        UpMemberPhone789  = findViewById(R.id.UpMemberPhoneTv789);

        UpMemberPhoneButton1  = findViewById(R.id.UpMemberPhoneButton1);
        UpMemberPhoneButton2  = findViewById(R.id.UpMemberPhoneButton2);
        UpMemberPhoneButton3  = findViewById(R.id.UpMemberPhoneButton3);
        UpMemberPhoneButton4   = findViewById(R.id.UpMemberPhoneButton4);
        UpMemberPhoneButton5  = findViewById(R.id.UpMemberPhoneButton5);
        UpMemberPhoneButton6  = findViewById(R.id.UpMemberPhoneButton6);
        UpMemberPhoneButton7  = findViewById(R.id.UpMemberPhoneButton7);
        UpMemberPhoneButton8  = findViewById(R.id.UpMemberPhoneButton8);
        UpMemberPhoneButton9  = findViewById(R.id.UpMemberPhoneButton9);
        UpMemberPhoneButton123  = findViewById(R.id.UpMemberPhoneButton123);
        UpMemberPhoneButton456  = findViewById(R.id.UpMemberPhoneButton456);
        UpMemberPhoneButton789  = findViewById(R.id.UpMemberPhoneButton789);

        UpMemberPhoneButton1.setOnClickListener(this);
        UpMemberPhoneButton2.setOnClickListener(this);
        UpMemberPhoneButton3.setOnClickListener(this);
        UpMemberPhoneButton4.setOnClickListener(this);
        UpMemberPhoneButton5.setOnClickListener(this);
        UpMemberPhoneButton6.setOnClickListener(this);
        UpMemberPhoneButton7.setOnClickListener(this);
        UpMemberPhoneButton8.setOnClickListener(this);
        UpMemberPhoneButton9.setOnClickListener(this);
        UpMemberPhoneButton123.setOnClickListener(this);
        UpMemberPhoneButton456.setOnClickListener(this);
        UpMemberPhoneButton789.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();

        if(bundle!= null){
            String UpMemberHeading = bundle.getString("UpMemberHeading");

            String upMemberName1 = bundle.getString("upMemberName1");
            String upMemberName2 = bundle.getString("upMemberName2");
            String upMemberName3 = bundle.getString("upMemberName3");
            String upMemberName4 = bundle.getString("upMemberName4");
            String upMemberName5 = bundle.getString("upMemberName5");
            String upMemberName6 = bundle.getString("upMemberName6");
            String upMemberName7 = bundle.getString("upMemberName7");
            String upMemberName8 = bundle.getString("upMemberName8");
            String upMemberName9 = bundle.getString("upMemberName9");
            String upMemberName123 = bundle.getString("upMemberName10");
            String upMemberName456 = bundle.getString("upMemberName11");
            String upMemberName789 = bundle.getString("upMemberName12");

            String upMemberPhone1 = bundle.getString("upMemberPhone1");
            String upMemberPhone2 = bundle.getString("upMemberPhone2");
            String upMemberPhone3 = bundle.getString("upMemberPhone3");
            String upMemberPhone4 = bundle.getString("upMemberPhone4");
            String upMemberPhone5 = bundle.getString("upMemberPhone5");
            String upMemberPhone6 = bundle.getString("upMemberPhone6");
            String upMemberPhone7 = bundle.getString("upMemberPhone7");
            String upMemberPhone8 = bundle.getString("upMemberPhone8");
            String upMemberPhone9 = bundle.getString("upMemberPhone9");
            String upMemberPhone123 = bundle.getString("upMemberPhone10");
            String upMemberPhone456 = bundle.getString("upMemberPhone11");
            String upMemberPhone789 = bundle.getString("upMemberPhone12");

            UpMemberHeadingTv.setText(UpMemberHeading);

            UpMemberName1.setText(upMemberName1);
            UpMemberName2.setText(upMemberName2);
            UpMemberName3.setText(upMemberName3);
            UpMemberName4.setText(upMemberName4);
            UpMemberName5.setText(upMemberName5);
            UpMemberName6.setText(upMemberName6);
            UpMemberName7.setText(upMemberName7);
            UpMemberName8.setText(upMemberName8);
            UpMemberName9.setText(upMemberName9);
            UpMemberName123.setText(upMemberName123);
            UpMemberName456.setText(upMemberName456);
            UpMemberName789.setText(upMemberName789);

            UpMemberPhone1.setText(upMemberPhone1);
            UpMemberPhone2.setText(upMemberPhone2);
            UpMemberPhone3.setText(upMemberPhone3);
            UpMemberPhone4.setText(upMemberPhone4);
            UpMemberPhone5.setText(upMemberPhone5);
            UpMemberPhone6.setText(upMemberPhone6);
            UpMemberPhone7.setText(upMemberPhone7);
            UpMemberPhone8.setText(upMemberPhone8);
            UpMemberPhone9.setText(upMemberPhone9);
            UpMemberPhone123.setText(upMemberPhone123);
            UpMemberPhone456.setText(upMemberPhone456);
            UpMemberPhone789.setText(upMemberPhone789);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.UpMemberPhoneButton1){
            String phoneNumber = UpMemberPhone1.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton2){
            String phoneNumber = UpMemberPhone2.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton3){
            String phoneNumber = UpMemberPhone3.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton4){
            String phoneNumber = UpMemberPhone4.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton5){
            String phoneNumber = UpMemberPhone1.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton6){
            String phoneNumber = UpMemberPhone6.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton7){
            String phoneNumber = UpMemberPhone7.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton8){
            String phoneNumber = UpMemberPhone8.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton9){
            String phoneNumber = UpMemberPhone9.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton123){
            String phoneNumber = UpMemberPhone123.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton456){
            String phoneNumber = UpMemberPhone456.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if(v.getId()==R.id.UpMemberPhoneButton789){
            String phoneNumber = UpMemberPhone789.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
    }
}
