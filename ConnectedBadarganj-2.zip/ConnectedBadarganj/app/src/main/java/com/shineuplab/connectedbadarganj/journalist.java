package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import com.google.firebase.auth.FirebaseAuth;

public class journalist extends AppCompatActivity implements View.OnClickListener {

    Button journalistBtn1,journalistBtn2,journalistBtn3,journalistBtn4,journalistBtn5,journalistBtn6,journalistBtn7,journalistBtn8,journalistBtn9,journalistBtn10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journalist);

        journalistBtn1 = findViewById(R.id.journalistBtn1);
        journalistBtn2 = findViewById(R.id.journalistBtn2);
        journalistBtn3 = findViewById(R.id.journalistBtn3);
        journalistBtn4 = findViewById(R.id.journalistBtn4);
        journalistBtn5 = findViewById(R.id.journalistBtn5);
        journalistBtn6 = findViewById(R.id.journalistBtn6);
        journalistBtn7 = findViewById(R.id.journalistBtn7);
        journalistBtn8 = findViewById(R.id.journalistBtn8);
        journalistBtn9 = findViewById(R.id.journalistBtn9);
        journalistBtn10 = findViewById(R.id.journalistBtn10);

        journalistBtn1.setOnClickListener(this);
        journalistBtn2.setOnClickListener(this);
        journalistBtn3.setOnClickListener(this);
        journalistBtn4.setOnClickListener(this);
        journalistBtn5.setOnClickListener(this);
        journalistBtn6.setOnClickListener(this);
        journalistBtn7.setOnClickListener(this);
        journalistBtn8.setOnClickListener(this);
        journalistBtn9.setOnClickListener(this);
        journalistBtn10.setOnClickListener(this);

    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId()== R.id.journalistBtn1){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn2){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn3){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn4){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn5){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn6){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn7){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn8){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn9){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }
        if (v.getId()== R.id.journalistBtn10){
            String phoneNumber = journalistBtn1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneNumber));
            startActivity(intent);
        }


    }
}