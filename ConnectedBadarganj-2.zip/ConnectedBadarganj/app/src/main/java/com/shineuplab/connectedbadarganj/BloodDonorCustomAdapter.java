package com.shineuplab.connectedbadarganj;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class BloodDonorCustomAdapter extends ArrayAdapter<BloodDonorModel> {

    private Activity context;
    private List <BloodDonorModel> donorList;

    public BloodDonorCustomAdapter(Activity context, List<BloodDonorModel> donorList) {
        super(context, R.layout.blood_donor_list, donorList);
        this.context = context;
        this.donorList = donorList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater layoutInflater = context.getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.blood_donor_list, null,true);

        BloodDonorModel bloodDonorModel = donorList.get(position);

        TextView BloodGroupTv = view.findViewById(R.id.bloodGroupTvId);
        TextView nameTv = view.findViewById(R.id.bloodDonorNameTvId);
        TextView PhoneTv = view.findViewById(R.id.bloodDonorPhoneTvId);

        BloodGroupTv.setText(bloodDonorModel.getBlood_group());
        nameTv.setText(bloodDonorModel.getName());
        PhoneTv.setText(bloodDonorModel.getPhone());
        return view;
    }
}
