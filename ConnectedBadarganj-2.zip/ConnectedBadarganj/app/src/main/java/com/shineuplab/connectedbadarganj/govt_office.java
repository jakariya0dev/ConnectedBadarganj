package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class govt_office extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_govt_office);


    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    public void UFPO(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_UFPO_name));
        intent.putExtra("designation", getString(R.string.govt_employee_UFPO_designation));
        intent.putExtra("description", getString(R.string.govt_employee_UFPO));
        intent.putExtra("email", getString(R.string.govt_employee_UFPO_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_UFPO_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_UFPO_phone));
        startActivity(intent);
    }

    public void ICT(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_ICT_name));
        intent.putExtra("designation", getString(R.string.govt_employee_ICT_designation));
        intent.putExtra("description", getString(R.string.govt_employee_ICT));
        intent.putExtra("email", getString(R.string.govt_employee_ICT_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_ICT_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_ICT_phone));
        startActivity(intent);
    }

    public void fisheries(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_fisheries_name));
        intent.putExtra("designation", getString(R.string.govt_employee_fisheries_designation));
        intent.putExtra("description", getString(R.string.govt_employee_fisheries));
        intent.putExtra("email", getString(R.string.govt_employee_fisheries_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_fisheries_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_fisheries_phone));
        startActivity(intent);
    }

    public void DLS(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_DLS_name));
        intent.putExtra("designation", getString(R.string.govt_employee_DLS_designation));
        intent.putExtra("description", getString(R.string.govt_employee_DLS));
        intent.putExtra("email", getString(R.string.govt_employee_DLS_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_DLS_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_DLS_phone));
        startActivity(intent);
    }

    public void AGRI(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_AGRI_name));
        intent.putExtra("designation", getString(R.string.govt_employee_AGRI_designation));
        intent.putExtra("description", getString(R.string.govt_employee_AGRI));
        intent.putExtra("email", getString(R.string.govt_employee_AGRI_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_AGRI_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_AGRI_phone));
        startActivity(intent);
    }

    public void EDU(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_EDU_name));
        intent.putExtra("designation", getString(R.string.govt_employee_EDU_designation));
        intent.putExtra("description", getString(R.string.govt_employee_EDU));
        intent.putExtra("email", getString(R.string.govt_employee_EDU_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_EDU_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_EDU_phone));
        startActivity(intent);
    }

    public void STAT(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_STAT_name));
        intent.putExtra("designation", getString(R.string.govt_employee_STAT_designation));
        intent.putExtra("description", getString(R.string.govt_employee_STAT));
        intent.putExtra("email", getString(R.string.govt_employee_STAT_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_STAT_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_STAT_phone));
        startActivity(intent);
    }

    public void BRDB(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_BRDB_name));
        intent.putExtra("designation", getString(R.string.govt_employee_BRDB_designation));
        intent.putExtra("description", getString(R.string.govt_employee_BRDB));
        intent.putExtra("email", getString(R.string.govt_employee_BRDB_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_BRDB_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_BRDB_phone));
        startActivity(intent);
    }

    public void Jute(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Jute_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Jute_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Jute));
        intent.putExtra("email", getString(R.string.govt_employee_Jute_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Jute_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Jute_phone));
        startActivity(intent);
    }

    public void BMDA(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_BMDA_name));
        intent.putExtra("designation", getString(R.string.govt_employee_BMDA_designation));
        intent.putExtra("description", getString(R.string.govt_employee_BMDA));
        intent.putExtra("email", getString(R.string.govt_employee_BMDA_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_BMDA_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_BMDA_phone));
        startActivity(intent);
    }

    public void Fire(View view) {

        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_BMDA_name));
        intent.putExtra("designation", getString(R.string.govt_employee_BMDA_designation));
        intent.putExtra("description", getString(R.string.govt_employee_BMDA));
        intent.putExtra("email", getString(R.string.govt_employee_BMDA_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_BMDA_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_BMDA_phone));
        startActivity(intent);
    }

    public void Accounts(View view) {

        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Accounts_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Accounts_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Accounts));
        intent.putExtra("email", getString(R.string.govt_employee_Accounts_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Accounts_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Accounts_phone));
        startActivity(intent);
    }

    public void Election(View view) {

        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Election_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Election_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Election));
        intent.putExtra("email", getString(R.string.govt_employee_Election_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Election_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Election_phone));
        startActivity(intent);
    }

    public void Social(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Social_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Social_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Social));
        intent.putExtra("email", getString(R.string.govt_employee_Social_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Social_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Social_phone));
        startActivity(intent);
    }

    public void Youth(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Youth_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Youth_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Youth));
        intent.putExtra("email", getString(R.string.govt_employee_Youth_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Youth_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Youth_phone));
        startActivity(intent);
    }

    public void Deposit(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Deposit_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Deposit_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Deposit));
        intent.putExtra("email", getString(R.string.govt_employee_Deposit_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Deposit_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Deposit_phone));
        startActivity(intent);
    }

    public void Women(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Women_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Women_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Women));
        intent.putExtra("email", getString(R.string.govt_employee_Women_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Women_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Women_phone));
        startActivity(intent);
    }

    public void Cashier(View view) {
        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_Cashier_name));
        intent.putExtra("designation", getString(R.string.govt_employee_Cashier_designation));
        intent.putExtra("description", getString(R.string.govt_employee_Cashier));
        intent.putExtra("email", getString(R.string.govt_employee_Cashier_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_Cashier_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_Cashier_phone));
        startActivity(intent);
    }

    public void MEDU(View view) {

        Intent intent = new Intent(getApplicationContext(), govt_employee_profile.class);
        intent.putExtra("name", getString(R.string.govt_employee_MEDU_name));
        intent.putExtra("designation", getString(R.string.govt_employee_MEDU_designation));
        intent.putExtra("description", getString(R.string.govt_employee_MEDU));
        intent.putExtra("email", getString(R.string.govt_employee_MEDU_email));
        intent.putExtra("mobile", getString(R.string.govt_employee_MEDU_mobile));
        intent.putExtra("phone", getString(R.string.govt_employee_MEDU_phone));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
