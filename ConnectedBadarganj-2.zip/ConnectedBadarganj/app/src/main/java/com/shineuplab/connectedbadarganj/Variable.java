package com.shineuplab.connectedbadarganj;

public class Variable {

    public static String UpMemberHeadingTv = "UpMemberHeading";

    public static String upMemberName1 = "upMemberName1";
    public static String upMemberName2 = "upMemberName2";
    public static String upMemberName3 = "upMemberName3";
    public static String upMemberName4 = "upMemberName4";
    public static String upMemberName5 = "upMemberName5";
    public static String upMemberName6 = "upMemberName6";
    public static String upMemberName7 = "upMemberName7";
    public static String upMemberName8 = "upMemberName8";
    public static String upMemberName9 = "upMemberName9";
    public static String upMemberName10 = "upMemberName10";
    public static String upMemberName11 = "upMemberName11";
    public static String upMemberName12 = "upMemberName12";

    public static String upMemberPhone1 = "upMemberPhone1";
    public static String upMemberPhone2 = "upMemberPhone2";
    public static String upMemberPhone3 = "upMemberPhone3";
    public static String upMemberPhone4 = "upMemberPhone4";
    public static String upMemberPhone5 = "upMemberPhone5";
    public static String upMemberPhone6 = "upMemberPhone6";
    public static String upMemberPhone7 = "upMemberPhone7";
    public static String upMemberPhone8 = "upMemberPhone8";
    public static String upMemberPhone9 = "upMemberPhone9";
    public static String upMemberPhone10 = "upMemberPhone10";
    public static String upMemberPhone11 = "upMemberPhone11";
    public static String upMemberPhone12 = "upMemberPhone12";
}
