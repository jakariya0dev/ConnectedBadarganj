package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class emergency_service2 extends AppCompatActivity implements View.OnClickListener {

    TextView headingOneTv, phoneOneTv, headingTwoTv, phoneTwoTv, emergencyHeadingTv;
    Button callButtonOne, callButtonTwo, smsButtonOne, smsButtonTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_service2);

        headingOneTv = findViewById(R.id.headingOneTv);
        phoneOneTv = findViewById(R.id.phoneOneTv);
        headingTwoTv = findViewById(R.id.headingTwoTv);
        phoneTwoTv = findViewById(R.id.phoneTwoTv);
        emergencyHeadingTv = findViewById(R.id.emergencyHeading);

        callButtonOne = findViewById(R.id.callButtonOne);
        callButtonTwo = findViewById(R.id.callButtonTwo);
        smsButtonOne = findViewById(R.id.smsButtonOne);
        smsButtonTwo = findViewById(R.id.smsButtonTwo);

        callButtonOne.setOnClickListener(this);
        callButtonTwo.setOnClickListener(this);
        smsButtonOne.setOnClickListener(this);
        smsButtonTwo.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();

        if (bundle!=null){
            String headingOne = bundle.getString("headingOne");
            String headingTwo = bundle.getString("headingTwo");
            String PhoneOne = bundle.getString("PhoneOne");
            String PhoneTwo = bundle.getString("PhoneTwo");
            String Title = bundle.getString("title");
            headingOneTv.setText(headingOne);
            phoneOneTv.setText(PhoneOne);
            headingTwoTv .setText(headingTwo);
            phoneTwoTv.setText(PhoneTwo);
            emergencyHeadingTv.setText(Title);
        }

    }

    @Override
    public void onClick(View v) {

        if (v.getId()==R.id.callButtonOne){
            String phoneOne = phoneOneTv.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneOne));
            startActivity(intent);
        }if (v.getId()==R.id.callButtonTwo){
            String phoneTwo = phoneTwoTv.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+phoneTwo));
            startActivity(intent);
        }if (v.getId()==R.id.smsButtonOne){
            String phoneOne = phoneOneTv.getText().toString();
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("tel:"+phoneOne));
            startActivity(intent);
        }if (v.getId()==R.id.smsButtonTwo){
            String phoneTwo = phoneTwoTv.getText().toString();
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("tel:"+phoneTwo));
            startActivity(intent);
        }
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}
