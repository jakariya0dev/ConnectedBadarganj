package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class doctorProfile extends AppCompatActivity {

    TextView DoctorNameTv, SpecialityTv, ScheduleTv, DoctorsDetailsTv, SerialTv;
    Button SerialBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        DoctorNameTv = findViewById(R.id.DoctorNameTv);
        SpecialityTv = findViewById(R.id.SpecialityTv);
        ScheduleTv = findViewById(R.id.ScheduleTv);
        DoctorsDetailsTv = findViewById(R.id.DoctorsDetailsTv);
        SerialTv = findViewById(R.id.SerialTv);
        SerialBtn = findViewById(R.id.SerialBtn);

        Bundle bundle = getIntent().getExtras();

        if (bundle!= null) {
            String Name = bundle.getString("name");
            String Speciality = bundle.getString("speciality");
            String Time = bundle.getString("time");
            String Details = bundle.getString("details");
            String Serial = bundle.getString("serial");

            DoctorNameTv.setText(Name);
            DoctorsDetailsTv.setText(Details);
            ScheduleTv.setText(Time);
            SpecialityTv.setText(Speciality);
            SerialTv.setText(Serial);

        }

        SerialBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SerialNumber = SerialTv.getText().toString();
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+SerialNumber));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
