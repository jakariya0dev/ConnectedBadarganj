package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class college extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college);
    }

    public void college_bgc(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_bgc));
        intent.putExtra("description",getString(R.string.college_bgc));
        startActivity(intent);
    }
    public void college_bwc(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_bwc));
        intent.putExtra("description",getString(R.string.college_bwc));
        startActivity(intent);
    }
    public void college_bakhshiganj(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_bakhshiganj));
        intent.putExtra("description",getString(R.string.college_bakhshiganj));
        startActivity(intent);
    }
    public void college_kutubpur(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_kutubpur));
        intent.putExtra("description",getString(R.string.college_kutubpur));
        startActivity(intent);
    }
    public void college_pirpal(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_pirpal));
        intent.putExtra("description",getString(R.string.college_pirpal));
        startActivity(intent);
    }
    public void college_vip(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.college_name_vip));
        intent.putExtra("description",getString(R.string.college_vip));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
