package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class dakhil_madrasah extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dakhil_madrasah);
        
    }

    public void madrasah_1(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_1));
        intent.putExtra("description",getString(R.string.madrasah_description_1));
        startActivity(intent);
    }
    public void madrasah_2(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_2));
        intent.putExtra("description",getString(R.string.madrasah_description_2));
        startActivity(intent);
    }
    public void madrasah_3(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_3));
        intent.putExtra("description",getString(R.string.madrasah_description_3));
        startActivity(intent);
    }
    public void madrasah_4(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_4));
        intent.putExtra("description",getString(R.string.madrasah_description_4));
        startActivity(intent);
    }
    public void madrasah_5(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_5));
        intent.putExtra("description",getString(R.string.madrasah_description_5));
        startActivity(intent);
    }
    public void madrasah_6(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_6));
        intent.putExtra("description",getString(R.string.madrasah_description_6));
        startActivity(intent);
    }
    public void madrasah_7(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_7));
        intent.putExtra("description",getString(R.string.madrasah_description_7));
        startActivity(intent);
    }
    public void madrasah_8(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_8));
        intent.putExtra("description",getString(R.string.madrasah_description_8));
        startActivity(intent);
    }
    public void madrasah_9(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_9));
        intent.putExtra("description",getString(R.string.madrasah_description_9));
        startActivity(intent);
    }
    public void madrasah_10(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_10));
        intent.putExtra("description",getString(R.string.madrasah_description_10));
        startActivity(intent);
    }
    public void madrasah_11(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_11));
        intent.putExtra("description",getString(R.string.madrasah_description_11));
        startActivity(intent);
    }
    public void madrasah_12(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_12));
        intent.putExtra("description",getString(R.string.madrasah_description_12));
        startActivity(intent);
    }
    public void madrasah_13(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_13));
        intent.putExtra("description",getString(R.string.madrasah_description_13));
        startActivity(intent);
    }
    public void madrasah_14(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_14));
        intent.putExtra("description",getString(R.string.madrasah_description_14));
        startActivity(intent);
    }
    public void madrasah_15(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_15));
        intent.putExtra("description",getString(R.string.madrasah_description_15));
        startActivity(intent);
    }
    public void madrasah_16(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_16));
        intent.putExtra("description",getString(R.string.madrasah_description_16));
        startActivity(intent);
    }
    public void madrasah_17(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_17));
        intent.putExtra("description",getString(R.string.madrasah_description_17));
        startActivity(intent);
    }
    public void madrasah_18(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_18));
        intent.putExtra("description",getString(R.string.madrasah_description_18));
        startActivity(intent);
    }
    public void madrasah_19(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalOrganizationProfile.class);
        Bundle bundle = new Bundle();
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.madrasah_name_19));
        intent.putExtra("description",getString(R.string.madrasah_description_19));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
