package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.firebase.auth.FirebaseAuth;


public class bdg_pourosova extends AppCompatActivity {

    ImageView Pourobg;
    LinearLayout welcomeText, Menu;
    Animation frombottom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bdg_pourosova);

        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);

        Pourobg = findViewById(R.id.bgImage);
        welcomeText = findViewById(R.id.welcomeTextId);
        Menu = findViewById(R.id.menuId);

        Pourobg.animate().translationY(-1500).setDuration(1500).setStartDelay(300);
        welcomeText.animate().translationY(-440).setDuration(1500).setStartDelay(300);

       // welcomeText.startAnimation(fromBottom);
        Menu.startAnimation(frombottom);

    }

    public void MayorCv(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.uttom);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.mayor_name));
        intent.putExtra("position",getString(R.string.mayor2));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.mayor_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }

    public void PanelMayorCv(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        Bundle bundle = new Bundle();
        bundle.putInt("proPic",R.drawable.man);
        intent.putExtras(bundle);
        intent.putExtra("name",getString(R.string.word_no_3_name));
        intent.putExtra("position",getString(R.string.panel_mayor2));
        intent.putExtra("description",getString(R.string.bdg_pourosova));
        intent.putExtra("phone",getString(R.string.word_no_3_phone));
        intent.putExtra("email",getString(R.string.mayor_email));
        startActivity(intent);
    }

    public void councilorCv(View view) {
        Intent intent = new Intent(getApplicationContext(), pouro_councilors.class);
        startActivity(intent);
    }

    public void employeeCv(View view) {
        Intent intent = new Intent(getApplicationContext(), pouro_employee.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.menu_resource_file,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.aboutUs){
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(getApplicationContext(), administration.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void OfflineAd(View view) {
        Intent intent = new Intent(getApplicationContext(),Adv_private.class);
        startActivity(intent);
    }
}
