package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;


public class DownTrain extends Fragment {


    public DownTrain() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_down_train, container, false);

        ListView listView = view.findViewById(R.id.DownTrainListId);
        String[] listItem = getResources().getStringArray(R.array.DownTrainListArray);


        ArrayAdapter<String> listViewAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_activated_1, listItem);
        listView.setAdapter(listViewAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_797));
                    i.putExtra("trainName", getString(R.string.name_797));
                    i.putExtra("arrived", getString(R.string.arrived_797));
                    i.putExtra("stops", getString(R.string.stops_797));
                    i.putExtra("EndPoint", getString(R.string.dhaka));
                    i.putExtra("StartingPoint", getString(R.string.kurigram));
                    i.putExtra("offDayTv", getString(R.string.wednesday));
                    startActivity(i);
                }
                if (position == 1) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_422));
                    i.putExtra("trainName", getString(R.string.name_422));
                    i.putExtra("arrived", getString(R.string.arrived_422));
                    i.putExtra("stops", getString(R.string.stops_422));
                    i.putExtra("EndPoint", getString(R.string.kurigram));
                    i.putExtra("StartingPoint", getString(R.string.parbotipur));
                    i.putExtra("offDayTv", getString(R.string.no));
                    startActivity(i);
                }
                if (position == 2) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_64));
                    i.putExtra("trainName", getString(R.string.name_64));
                    i.putExtra("arrived", getString(R.string.arrived_64));
                    i.putExtra("stops", getString(R.string.stops_64));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    i.putExtra("StartingPoint", getString(R.string.lalmonirhat));
                    i.putExtra("offDayTv", getString(R.string.no));
                    startActivity(i);
                }
                if (position == 3) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_768));
                    i.putExtra("trainName", getString(R.string.name_768));
                    i.putExtra("arrived", getString(R.string.arrived_768));
                    i.putExtra("stops", getString(R.string.stops_768));
                    i.putExtra("StartingPoint", getString(R.string.santahar));
                    i.putExtra("EndPoint", getString(R.string.parbotipur));
                    i.putExtra("EndPoint", getString(R.string.lalmonirhat));
                    i.putExtra("StartingPoint", getString(R.string.parbotipur));
                    i.putExtra("offDayTv", getString(R.string.sunday));
                    startActivity(i);
                }
                if (position == 4) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_dc_2));
                    i.putExtra("trainName", getString(R.string.name_dc_2));
                    i.putExtra("arrived", getString(R.string.arrived_dc_2));
                    i.putExtra("stops", getString(R.string.stops_dc_2));
                    i.putExtra("EndPoint", getString(R.string.lalmonirhat));
                    i.putExtra("StartingPoint", getString(R.string.parbotipur));
                    i.putExtra("offDayTv", getString(R.string.monday));
                    startActivity(i);
                }
                if (position == 5) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_62));
                    i.putExtra("trainName", getString(R.string.name_62));
                    i.putExtra("arrived", getString(R.string.arrived_62));
                    i.putExtra("stops", getString(R.string.stops_62));
                    i.putExtra("EndPoint", getString(R.string.lalmonirhat));
                    i.putExtra("StartingPoint", getString(R.string.dinajpur));
                    i.putExtra("offDayTv", getString(R.string.no));
                    startActivity(i);
                }
                if (position == 6) {
                    Intent i = new Intent(getActivity(), train.class);
                    i.putExtra("trainNo", getString(R.string.train_no_62));
                    i.putExtra("trainName", getString(R.string.name_62));
                    i.putExtra("arrived", getString(R.string.arrived_62));
                    i.putExtra("stops", getString(R.string.stops_62));
                    i.putExtra("EndPoint", getString(R.string.kurigram));
                    i.putExtra("StartingPoint", getString(R.string.parbotipur));
                    i.putExtra("offDayTv", getString(R.string.no));
                    startActivity(i);
                }
            }
        });
        return view;

    }


}
