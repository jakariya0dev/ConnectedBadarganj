package com.shineuplab.connectedbadarganj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class BloodDonorRegForm extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText signUpNameEditText, signPhoneEditText, signUpEmailEditText, signUpPasswordEditText;
    Button SignUpButton;
    ProgressBar progressBar;
    Spinner spinner;
    String blood_group;

    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("blood_donor");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_donor_reg_form);

        signUpNameEditText = findViewById(R.id.signUpNameEditText);
        spinner = findViewById(R.id.spinner);
        signPhoneEditText = findViewById(R.id.signUpPhoneEditText);
        signUpEmailEditText  = findViewById(R.id.signUpEmailEditText);
        signUpPasswordEditText = findViewById(R.id.signUpPasswordEditText);

        SignUpButton = findViewById(R.id.SignUpButton);
        progressBar = findViewById(R.id.signUpProgressBarId);

        ArrayAdapter <CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.blood_group, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        mAuth = FirebaseAuth.getInstance();

        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String name = signUpNameEditText.getText().toString().trim();
                final String phone = signPhoneEditText.getText().toString().trim();
                final String email = signUpEmailEditText.getText().toString().trim();
                final String password = signUpPasswordEditText.getText().toString().trim();

                if (name.isEmpty()) {
                    signUpNameEditText.setError("Enter an User Name");
                    signUpNameEditText.requestFocus();
                    return;
                }
                if (phone.isEmpty()) {
                    signPhoneEditText.setError("Enter a Phone Number");
                    signPhoneEditText.requestFocus();
                    return;
                }
                if (phone.length() < 11){
                    signPhoneEditText.setError("Phone Number Must Be 11 Digit");
                    signPhoneEditText.requestFocus();
                    return;
                }
                if (email.isEmpty()) {
                    signUpEmailEditText.setError("Enter Your Email Address");
                    signUpEmailEditText.requestFocus();
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    signUpEmailEditText.setError("Enter Your Email Address");
                    signUpEmailEditText.requestFocus();
                    return;
                }
                if (password.isEmpty()) {
                    signUpPasswordEditText.setError("Enter a Password");
                    signUpPasswordEditText.requestFocus();
                    return;
                }
                if (password.length() < 6) {
                    signUpPasswordEditText.setError("Password must be 6 Charectar or more");
                    signUpPasswordEditText.requestFocus();
                    return;
                }

                String key = databaseReference.push().getKey();

                BloodDonorModel bloodDonorModel = new BloodDonorModel(name, blood_group, phone);

                databaseReference.child(key).setValue(bloodDonorModel);

                progressBar.setVisibility(View.VISIBLE);

                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Authentication Success.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), BloodDonorDashboard.class);
                            startActivity(intent);

                        }
                        else {
                            Toast.makeText(getApplicationContext(), Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }

                    }
                });




            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        blood_group = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}